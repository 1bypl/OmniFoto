"""OmniFoto - lokalna przeglądarka i wyszukiwarka tapet.

Aplikacja działa wyłącznie na komputerze użytkownika. Nie śledzi go,
nie wysyła danych telemetrycznych i jest udostępniona na licencji GPL-3.0.
"""

__version__ = "1.0.0"
APP_NAME = "OmniFoto"
AUTHOR = "1bypl"
GITHUB = "https://github.com/1bypl"
LICENSE = "GPL-3.0-or-later"
