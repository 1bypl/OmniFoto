"""Górny pasek: wyszukiwarka, filtry, przełącznik skórek i postęp wyszukiwania."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QSizePolicy,
    QVBoxLayout,
)

from ..models import SortKey, TimeRange, ViewMode
from .widgets import SearchProgressWidget

SORT_LABELS = {
    SortKey.RELEVANCE: "sort_relevance", SortKey.QUALITY: "sort_quality",
    SortKey.RESOLUTION: "sort_resolution", SortKey.DATE: "sort_date",
    SortKey.SIZE: "sort_size", SortKey.FORMAT: "sort_format",
    SortKey.POPULARITY: "sort_popularity", SortKey.DOWNLOADS: "sort_downloads",
}
TIME_LABELS = {
    TimeRange.ALL: "time_all", TimeRange.DAY: "time_day", TimeRange.WEEK: "time_week",
    TimeRange.MONTH: "time_month", TimeRange.YEAR: "time_year",
}


class SearchBar(QFrame):
    search_requested = Signal(str)
    sort_changed = Signal(object)
    time_changed = Signal(object)
    view_changed = Signal(object)
    favorite_filter_toggled = Signal(bool)
    slideshow_requested = Signal()
    theme_cycle_clicked = Signal()
    more_requested = Signal()
    refresh_requested = Signal()
    accumulate_toggled = Signal(bool)

    def __init__(self, translator, settings, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("header")
        self.tr = translator
        self.settings = settings
        self._updating = False
        self.progress_widget = SearchProgressWidget()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 3, 10, 2)
        outer.setSpacing(1)

        # --- wiersz 1: wyszukiwarka + akcje (prawo: skórki) -----------------
        row = QHBoxLayout()
        row.setSpacing(7)

        self.input = QLineEdit()
        self.input.setObjectName("searchInput")
        self.input.setPlaceholderText(self.tr.t("search_placeholder"))
        self.input.setMinimumWidth(150)
        self.input.setFixedHeight(28)
        self.input.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.input.returnPressed.connect(self._emit_search)
        row.addWidget(self.input, stretch=1)

        self.search_button = QPushButton("🔍 " + self.tr.t("search"))
        self.search_button.setObjectName("searchButton")
        self.search_button.setFixedHeight(28)
        self.search_button.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        self.search_button.clicked.connect(self._emit_search)
        row.addWidget(self.search_button)

        self.fav_filter = QPushButton("⭐")
        self.fav_filter.setObjectName("chip")
        self.fav_filter.setCheckable(True)
        self.fav_filter.setFixedSize(32, 28)
        self.fav_filter.setToolTip(self.tr.t("favorites"))
        self.fav_filter.toggled.connect(self.favorite_filter_toggled.emit)
        row.addWidget(self.fav_filter)

        self.tiles_btn = QPushButton("▦")
        self.tiles_btn.setObjectName("chip")
        self.tiles_btn.setCheckable(True)
        self.tiles_btn.setFixedSize(30, 28)
        self.tiles_btn.setToolTip(self.tr.t("tiles"))
        self.list_btn = QPushButton("☰")
        self.list_btn.setObjectName("chip")
        self.list_btn.setCheckable(True)
        self.list_btn.setFixedSize(30, 28)
        self.list_btn.setToolTip(self.tr.t("list"))
        mode = settings.get("view_mode", "tiles")
        self.tiles_btn.setChecked(mode == "tiles")
        self.list_btn.setChecked(mode == "list")
        self.tiles_btn.clicked.connect(lambda: self._set_view(ViewMode.TILES))
        self.list_btn.clicked.connect(lambda: self._set_view(ViewMode.LIST))
        row.addWidget(self.tiles_btn)
        row.addWidget(self.list_btn)

        self.slideshow_btn = QPushButton("▶")
        self.slideshow_btn.setObjectName("chip")
        self.slideshow_btn.setFixedSize(30, 28)
        self.slideshow_btn.setToolTip(self.tr.t("slideshow"))
        self.slideshow_btn.clicked.connect(self.slideshow_requested.emit)
        row.addWidget(self.slideshow_btn)

        # przycisk zmiany skórki - zawsze po prawej stronie
        self.theme_button = QPushButton("🎨")
        self.theme_button.setObjectName("themeButton")
        self.theme_button.setFixedSize(32, 28)
        self.theme_button.setToolTip(self.tr.t("theme_cycle"))
        self.theme_button.clicked.connect(self.theme_cycle_clicked.emit)
        row.addWidget(self.theme_button)
        outer.addLayout(row)

        # --- wiersz 2: filtry ------------------------------------------------
        filters = QHBoxLayout()
        filters.setSpacing(5)

        self.sort_combo = QComboBox()
        self.sort_combo.setObjectName("chip")
        self.sort_combo.setFixedHeight(24)
        self._fill_sort()
        self.sort_combo.currentIndexChanged.connect(self._on_sort)
        filters.addWidget(self.sort_combo)

        self.time_combo = QComboBox()
        self.time_combo.setObjectName("chip")
        self.time_combo.setFixedHeight(24)
        self._fill_time()
        self.time_combo.currentIndexChanged.connect(self._on_time)
        filters.addWidget(self.time_combo)

        self.more_btn = QPushButton("＋ " + self.tr.t("more"))
        self.more_btn.setObjectName("chip")
        self.more_btn.setFixedHeight(24)
        self.more_btn.setToolTip(self.tr.t("more_hint"))
        self.more_btn.clicked.connect(self.more_requested.emit)
        filters.addWidget(self.more_btn)

        self.refresh_btn = QPushButton("🔄")
        self.refresh_btn.setObjectName("chip")
        self.refresh_btn.setFixedSize(28, 24)
        self.refresh_btn.setToolTip(self.tr.t("refresh_sources"))
        self.refresh_btn.clicked.connect(self.refresh_requested.emit)
        filters.addWidget(self.refresh_btn)

        self.accumulate_btn = QPushButton("⊕")
        self.accumulate_btn.setObjectName("chip")
        self.accumulate_btn.setFixedSize(28, 24)
        self.accumulate_btn.setCheckable(True)
        self.accumulate_btn.setChecked(True)
        self.accumulate_btn.setToolTip(self.tr.t("accumulate_hint"))
        self.accumulate_btn.toggled.connect(self.accumulate_toggled.emit)
        filters.addWidget(self.accumulate_btn)

        # postęp w tym samym wierszu co filtry - oszczędza miejsce na kafelki
        self.progress_widget.setFixedHeight(18)
        self.progress_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        filters.addWidget(self.progress_widget, stretch=1)

        self.hint = QLabel("🔒")
        self.hint.setObjectName("hint")
        self.hint.setFixedWidth(18)
        self.hint.setToolTip(self.tr.t("privacy_hint") + "\n" + self.tr.t("search_engine_hint"))
        filters.addWidget(self.hint)
        outer.addLayout(filters)

    # --- obsługa -----------------------------------------------------------
    def _emit_search(self) -> None:
        text = self.input.text().strip()
        if text:
            self.search_requested.emit(text)

    def set_searching(self, active: bool) -> None:
        self.progress_widget.set_active(active)
        self.search_button.setEnabled(not active)
        self.more_btn.setEnabled(not active)
        self.search_button.setText("⏳ " + self.tr.t("searching") if active else "🔍 " + self.tr.t("search"))

    def set_progress_colors(self, colors: dict[str, str]) -> None:
        self.progress_widget.set_colors(colors)

    def reset_progress(self) -> None:
        self.progress_widget.reset()

    def set_elapsed(self, seconds: float) -> None:
        self.progress_widget.set_elapsed(seconds)

    def set_source_progress(self, name: str, count: int, ok: bool) -> None:
        self.progress_widget.set_source_progress(name, count, ok)

    def set_counts(self, results: int, sources: int) -> None:
        self.progress_widget.set_total(results)

    def set_status(self, text: str) -> None:
        self.progress_widget.set_message(text)

    def _set_view(self, mode: ViewMode) -> None:
        self.tiles_btn.setChecked(mode == ViewMode.TILES)
        self.list_btn.setChecked(mode == ViewMode.LIST)
        self.view_changed.emit(mode)

    def set_view(self, mode: ViewMode) -> None:
        self._set_view(mode)

    def sort_key(self) -> SortKey:
        return SortKey(self.sort_combo.currentData())

    def time_range(self) -> TimeRange:
        return TimeRange(self.time_combo.currentData())

    def _fill_sort(self) -> None:
        self.sort_combo.clear()
        for key, label_key in SORT_LABELS.items():
            self.sort_combo.addItem(self.tr.t(label_key), key)

    def _fill_time(self) -> None:
        self.time_combo.clear()
        for key, label_key in TIME_LABELS.items():
            self.time_combo.addItem(self.tr.t(label_key), key)

    def _on_sort(self) -> None:
        if not self._updating:
            self.sort_changed.emit(self.sort_combo.currentData())

    def _on_time(self) -> None:
        if not self._updating:
            self.time_changed.emit(self.time_combo.currentData())

    def retranslate(self) -> None:
        self.input.setPlaceholderText(self.tr.t("search_placeholder"))
        self.search_button.setText("🔍 " + self.tr.t("search"))
        self.hint.setText("🔒")
        self.fav_filter.setToolTip(self.tr.t("favorites"))
        self.theme_button.setToolTip(self.tr.t("theme_cycle"))
        self.tiles_btn.setToolTip(self.tr.t("tiles"))
        self.list_btn.setToolTip(self.tr.t("list"))
        self.slideshow_btn.setToolTip(self.tr.t("slideshow"))
        self.refresh_btn.setToolTip(self.tr.t("refresh_sources"))
        self.accumulate_btn.setToolTip(self.tr.t("accumulate_hint"))
        self._updating = True
        self._fill_sort()
        self._fill_time()
        self._updating = False
