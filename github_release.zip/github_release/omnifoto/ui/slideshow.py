"""Tryb pokazu slajdów: strzałki, zoom kółkiem myszy, przesuwanie przeciąganiem."""

from __future__ import annotations

from PySide6.QtCore import QPoint, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QKeyEvent, QMouseEvent, QPixmap, QWheelEvent
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from ..models import Wallpaper
from .image_loader import ImageLoader


def _k(name: str) -> int:
    """Odporny dostęp do kodów klawiszy (różnice między wersjami PySide6)."""
    return int(getattr(Qt.Key, name, getattr(Qt, name, 0)))


class Slideshow(QWidget):
    favorite_toggled = Signal(object)
    download_clicked = Signal(object)

    def __init__(self, translator, loader: ImageLoader, colors: dict[str, str], parent=None) -> None:
        super().__init__(parent, Qt.WindowType.Window)
        self.setObjectName("slideshow")
        self.setWindowTitle("OmniFoto — " + translator.t("slideshow"))
        self.setWindowState(Qt.WindowState.WindowMaximized)
        self.tr = translator
        self.loader = loader
        self.colors = colors
        self.items: list[Wallpaper] = []
        self.index = 0
        self.zoom = 1.0
        self._pan = QPoint(0, 0)
        self._drag_start: QPoint | None = None
        self._pixmap = QPixmap()
        self._key = ""
        self._is_fav = False

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.image = QLabel("⏳")
        self.image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image.setMinimumSize(400, 300)
        self.image.setCursor(Qt.CursorShape.OpenHandCursor)
        self.image.setMouseTracking(True)
        root.addWidget(self.image, stretch=1)

        # mały, ruchomy podgląd szczegółów pod kursorem
        self.hover = QLabel(self)
        self.hover.setObjectName("slideshowBar")
        self.hover.setStyleSheet("color:white; background:rgba(0,0,0,190); padding:6px 9px; border-radius:7px;")
        self.hover.hide()

        bar = QHBoxLayout()
        bar.setContentsMargins(16, 10, 16, 12)
        bar.setSpacing(8)

        self.prev_btn = QPushButton("◀ " + self.tr.t("previous"))
        self.next_btn = QPushButton(self.tr.t("next") + " ▶")
        self.zoom_in_btn = QPushButton("＋ " + self.tr.t("zoom_in"))
        self.zoom_out_btn = QPushButton("－ " + self.tr.t("zoom_out"))
        self.play_btn = QPushButton("⏵ Auto")
        self.play_btn.setCheckable(True)
        self.star_btn = QPushButton("☆")
        self.download_btn = QPushButton("⬇ " + self.tr.t("download"))
        self.close_btn = QPushButton("✕ " + self.tr.t("close"))
        for btn in (self.prev_btn, self.next_btn, self.zoom_in_btn, self.zoom_out_btn,
                    self.play_btn, self.star_btn, self.download_btn, self.close_btn):
            btn.setObjectName("slideshowButton")
        self.prev_btn.clicked.connect(self.previous)
        self.next_btn.clicked.connect(self.next)
        self.zoom_in_btn.clicked.connect(lambda: self._zoom(1.25))
        self.zoom_out_btn.clicked.connect(lambda: self._zoom(0.8))
        self.play_btn.toggled.connect(self._set_autoplay)
        self.star_btn.clicked.connect(self._star)
        self.download_btn.clicked.connect(self._download)
        self.close_btn.clicked.connect(self.close)

        self.auto_timer = QTimer(self)
        self.auto_timer.setInterval(4000)
        self.auto_timer.timeout.connect(self.next)

        self.info = QLabel()
        self.info.setObjectName("slideshowBar")
        self.info.setWordWrap(True)
        self.info.setMinimumWidth(220)
        self.info.setStyleSheet("color: white; padding: 8px 12px;")

        bar.addWidget(self.prev_btn)
        bar.addWidget(self.next_btn)
        bar.addWidget(self.zoom_in_btn)
        bar.addWidget(self.zoom_out_btn)
        bar.addWidget(self.play_btn)
        bar.addStretch(1)
        bar.addWidget(self.star_btn)
        bar.addWidget(self.download_btn)
        bar.addWidget(self.close_btn)

        # szczegóły w osobnym wierszu - nie zlewają się z przyciskami
        # nawet na węższym ekranie
        bottom = QVBoxLayout()
        bottom.setContentsMargins(16, 6, 16, 12)
        bottom.setSpacing(4)
        bottom.addWidget(self.info)
        bottom.addLayout(bar)
        root.addLayout(bottom)

    # --- nawigacja ---------------------------------------------------------
    def set_items(self, items: list[Wallpaper], index: int = 0) -> None:
        self.items = list(items)
        self.index = max(0, min(index, len(self.items) - 1))
        self.show_current()

    def show_current(self) -> None:
        if not self.items:
            self.image.setText("Brak zdjęć")
            self.info.setText("")
            return
        w = self.items[self.index]
        size = self.image.size() if not self.image.size().isEmpty() else QSize(1200, 700)
        display_url = w.thumb_url or w.url
        self._key = self.loader.key(display_url, size)
        self._pixmap = QPixmap()
        self._pan = QPoint(0, 0)
        self.image.setText("⏳")
        self.loader.load(display_url, size)
        self.info.setText(self._details_text(w))
        self.star_btn.setText("★" if self._is_fav else "☆")

    def _details_text(self, w: Wallpaper) -> str:
        text = (
            f"{self.index + 1} / {len(self.items)}   •   {w.title}\n"
            f"📐 {w.resolution}   •   🗂 {w.format or '—'}   •   💾 {w.size_text}   •   🌐 {w.source_name or '—'}"
        )
        if w.author:
            text += f"   •   👤 {w.author}"
        return text

    def on_pixmap(self, key: str, pixmap: QPixmap) -> None:
        if key != self._key or pixmap.isNull():
            return
        self._pixmap = pixmap
        self._apply_pixmap()

    def _apply_pixmap(self) -> None:
        if self._pixmap.isNull():
            return
        scaled = self._pixmap.scaled(
            self._pixmap.size() * self.zoom,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.image.setPixmap(scaled)

    # --- zoom i przesuwanie ------------------------------------------------
    def _zoom(self, factor: float) -> None:
        self.zoom = max(0.25, min(8.0, self.zoom * factor))
        if abs(self.zoom - 1.0) < 0.01:
            self._pan = QPoint(0, 0)
        self._apply_pixmap()

    def wheelEvent(self, event: QWheelEvent) -> None:  # noqa: N802
        delta = event.angleDelta().y()
        if delta == 0:
            return
        self._zoom(1.15 if delta > 0 else 0.87)
        if self.items:
            self.hover.setText(f"🔍 {int(self.zoom * 100)}% — kółkiem zoom, przeciągnij myszką, by obejrzeć detale")
            pos = event.position().toPoint()
            self.hover.move(pos.x() + 14, pos.y() + 14)
            self.hover.show()
            self.hover.raise_()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self.zoom > 1.0:
            self._drag_start = event.position().toPoint()
            self.image.setCursor(Qt.CursorShape.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        pos = event.position().toPoint()
        if self._drag_start is not None and self.zoom > 1.0:
            self._pan += pos - self._drag_start
            self._drag_start = pos
            self._apply_pixmap()
        elif self.items:
            w = self.items[self.index]
            self.hover.setText(
                f"{w.title[:50]} • {w.resolution} • {w.format or '—'} • {w.size_text}"
            )
            self.hover.move(pos.x() + 14, pos.y() + 14)
            self.hover.show()
            self.hover.raise_()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        self._drag_start = None
        self.image.setCursor(Qt.CursorShape.OpenHandCursor)
        super().mouseReleaseEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self.hover.hide()
        super().leaveEvent(event)

    # --- pokaz automatyczny ------------------------------------------------
    def _set_autoplay(self, active: bool) -> None:
        self.play_btn.setText("⏸ Stop" if active else "⏵ Auto")
        if active:
            self.auto_timer.start()
        else:
            self.auto_timer.stop()

    def next(self) -> None:
        if not self.items:
            return
        self.index = (self.index + 1) % len(self.items)
        self.zoom = 1.0
        self.show_current()

    def previous(self) -> None:
        if not self.items:
            return
        self.index = (self.index - 1) % len(self.items)
        self.zoom = 1.0
        self.show_current()

    def set_favorite(self, value: bool) -> None:
        self._is_fav = value
        self.star_btn.setText("★" if value else "☆")

    def _star(self) -> None:
        if self.items:
            self.favorite_toggled.emit(self.items[self.index])

    def _download(self) -> None:
        if self.items:
            self.download_clicked.emit(self.items[self.index])

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        key = event.key()
        if key == _k("Key_Right"):
            self.next()
        elif key == _k("Key_Left"):
            self.previous()
        elif key in (_k("Key_Escape"), _k("Key_Q")):
            self.close()
        elif key in (_k("Key_Plus"), _k("Key_Equal")):
            self._zoom(1.25)
        elif key == _k("Key_Minus"):
            self._zoom(0.8)
        else:
            super().keyPressEvent(event)
