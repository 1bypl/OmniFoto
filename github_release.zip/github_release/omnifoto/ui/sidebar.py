"""Lewy panel: maskotka Azureus, logo i nawigacja główna."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QButtonGroup, QFrame, QLabel, QPushButton, QScrollArea, QSizePolicy,
    QVBoxLayout, QWidget,
)

from .. import __version__
from ..constants import APP_NAME

ASSETS = Path(__file__).resolve().parent.parent / "assets"


def svg_pixmap(path: Path | str, size: QSize) -> QPixmap:
    """Renderuje plik SVG do QPixmap (bez zależności od wtyczki QIcon)."""
    renderer = QSvgRenderer(str(path))
    if not renderer.isValid():
        return QPixmap()
    image = QImage(size, QImage.Format.Format_ARGB32_Premultiplied)
    image.fill(Qt.GlobalColor.transparent)
    painter = QPainter(image)
    painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source)
    renderer.render(painter)
    painter.end()
    return QPixmap.fromImage(image)


NAV_ITEMS = [
    ("home", "🏠", "home"),
    ("favorites", "⭐", "favorites"),
    ("collections", "📚", "collections"),
    ("categories", "🗂️", "categories"),
    ("best", "🏆", "best"),
    ("recent", "🕘", "recent"),
    ("settings", "⚙️", "settings"),
    ("about", "ℹ️", "about"),
]


class Sidebar(QFrame):
    nav_clicked = Signal(str)
    category_clicked = Signal(str)
    collection_opened = Signal(str)

    def __init__(self, translator, settings, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setMinimumWidth(186)
        self.setMaximumWidth(240)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        self.tr = translator
        self.settings = settings
        self._nav_buttons: dict[str, QPushButton] = {}
        self._cat_buttons: dict[str, QPushButton] = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 16, 12, 14)
        root.setSpacing(8)

        # --- Logo i maskotka ------------------------------------------------
        logo_box = QFrame()
        logo_box.setObjectName("logoBox")
        logo_layout = QVBoxLayout(logo_box)
        logo_layout.setContentsMargins(0, 0, 0, 0)
        logo_layout.setSpacing(2)
        logo_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        frog = QLabel()
        frog.setObjectName("mascotLabel")
        frog.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        frog.setPixmap(svg_pixmap(ASSETS / "mascot.svg", QSize(84, 84)))
        frog.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_layout.addWidget(frog)

        title = QLabel(APP_NAME)
        title.setObjectName("logoTitle")
        title.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_layout.addWidget(title)

        sub = QLabel(f"v{__version__} • autor {self.settings.get('author', '1bypl')}")
        sub.setObjectName("logoSub")
        sub.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_layout.addWidget(sub)
        root.addWidget(logo_box)

        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet("background: #2c4470;")
        root.addWidget(line)

        # --- Nawigacja ------------------------------------------------------
        nav_title = QLabel("MENU GŁÓWNE")
        nav_title.setObjectName("navTitle")
        root.addWidget(nav_title)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        for key, icon, _ in NAV_ITEMS:
            btn = QPushButton(f"{icon}  {self._label(key)}")
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked=False, k=key: self.nav_clicked.emit(k))
            self.nav_group.addButton(btn)
            root.addWidget(btn)
            self._nav_buttons[key] = btn

        root.addStretch(1)

        # --- Kategorie ------------------------------------------------------
        cat_title = QLabel(self.tr.t("categories").upper())
        cat_title.setObjectName("navTitle")
        root.addWidget(cat_title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(110)
        scroll.setMaximumHeight(170)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        cat_widget = QWidget()
        cat_layout = QVBoxLayout(cat_widget)
        cat_layout.setContentsMargins(0, 0, 0, 0)
        cat_layout.setSpacing(2)
        self._cat_layout = cat_layout
        all_btn = QPushButton("🌐  " + self.tr.t("all_categories"))
        all_btn.setObjectName("navButton")
        all_btn.setCheckable(True)
        all_btn.setChecked(True)
        all_btn.clicked.connect(lambda: self._on_category("all"))
        cat_layout.addWidget(all_btn)
        self._cat_buttons["all"] = all_btn
        for cat in self.settings.get("categories", []):
            btn = QPushButton(f"{cat.get('icon','•')}  {cat.get('name', cat.get('id',''))}")
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            cid = cat.get("id", "")
            btn.clicked.connect(lambda checked=False, c=cid: self._on_category(c))
            cat_layout.addWidget(btn)
            self._cat_buttons[cid] = btn
        cat_layout.addStretch(1)
        scroll.setWidget(cat_widget)
        root.addWidget(scroll)

        # --- własne kolekcje (widoczne od razu w głównym widoku) -----------
        col_title = QLabel(self.tr.t("collections").upper())
        col_title.setObjectName("navTitle")
        root.addWidget(col_title)

        col_scroll = QScrollArea()
        col_scroll.setWidgetResizable(True)
        col_scroll.setMinimumHeight(46)
        col_scroll.setMaximumHeight(92)
        col_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        col_widget = QWidget()
        self._collections_layout = QVBoxLayout(col_widget)
        self._collections_layout.setContentsMargins(0, 0, 0, 0)
        self._collections_layout.setSpacing(2)
        col_scroll.setWidget(col_widget)
        root.addWidget(col_scroll)
        self._fill_collections()

        # zaznacz „Start”
        self.select_nav("home")

    def _label(self, key: str) -> str:
        return self.tr.t(key)

    def _on_category(self, cid: str) -> None:
        for key, btn in self._cat_buttons.items():
            btn.setChecked(key == cid)
        self.category_clicked.emit(cid)

    def select_nav(self, key: str) -> None:
        btn = self._nav_buttons.get(key)
        if btn is not None:
            btn.setChecked(True)

    def select_category(self, cid: str) -> None:
        btn = self._cat_buttons.get(cid)
        if btn is not None:
            btn.setChecked(True)

    def _fill_collections(self) -> None:
        layout = getattr(self, "_collections_layout", None)
        if layout is None:
            return
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        collections = self.settings.collections()
        if not collections:
            empty = QLabel("—")
            empty.setObjectName("hint")
            layout.addWidget(empty)
            return
        for col in collections:
            name = col.get("name", "Kolekcja")
            count = len(col.get("items", []))
            btn = QPushButton(f"📚 {name[:18]} ({count})")
            btn.setObjectName("navButton")
            btn.setToolTip(f"{name} — {count} tapet")
            btn.clicked.connect(lambda checked=False, n=name: self.collection_opened.emit(n))
            layout.addWidget(btn)

    def refresh_collections(self) -> None:
        self._fill_collections()

    def retranslate(self) -> None:
        for key, icon, _ in NAV_ITEMS:
            btn = self._nav_buttons.get(key)
            if btn is not None:
                btn.setText(f"{icon}  {self._label(key)}")

    def retranslate_all(self) -> None:
        """Aktualizuje etykiety i listę kategorii po zmianie języka/ustawień."""
        self.retranslate()
        layout = getattr(self, "_cat_layout", None)
        if layout is None:
            return
        while layout.count() > 1:  # pierwszy przycisk: „wszystkie”
            item = layout.takeAt(1)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
        self._cat_buttons = {}
        all_btn = layout.itemAt(0).widget()
        all_btn.setText("🌐  " + self.tr.t("all_categories"))
        self._cat_buttons["all"] = all_btn
        for cat in self.settings.get("categories", []):
            btn = QPushButton(f"{cat.get('icon','•')}  {cat.get('name', cat.get('id',''))}")
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            cid = cat.get("id", "")
            btn.clicked.connect(lambda checked=False, c=cid: self._on_category(c))
            layout.addWidget(btn)
            self._cat_buttons[cid] = btn
        self._fill_collections()
