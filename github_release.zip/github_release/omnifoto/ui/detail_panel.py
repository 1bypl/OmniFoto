"""Panel szczegółów wybranej tapety (podgląd, metadane, akcje)."""

from __future__ import annotations

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QDesktopServices, QFontMetrics, QPixmap
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QSizePolicy,
    QVBoxLayout, QWidget,
)

from ..models import Quality, Wallpaper
from .image_loader import ImageLoader
from .widgets import DeviceBadges, QualityDot

BIG_SIZE = QSize(720, 460)


class DetailPanel(QFrame):
    preview_requested = Signal(object)
    download_clicked = Signal(object)
    favorite_toggled = Signal(object)
    add_to_collection = Signal(object)
    slideshow_requested = Signal()

    def __init__(self, translator, loader: ImageLoader, colors: dict[str, str], parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("detailPanel")
        self.setMinimumWidth(270)
        self.setMaximumWidth(360)
        self.tr = translator
        self.loader = loader
        self.colors = colors
        self.wallpaper: Wallpaper | None = None
        self._big_key = ""

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 14, 14, 14)
        outer.setSpacing(10)

        header = QHBoxLayout()
        self.title = QLabel(self.tr.t("details"))
        self.title.setObjectName("detailTitle")
        header.addWidget(self.title, stretch=1)
        close_btn = QPushButton("✕")
        close_btn.setToolTip(self.tr.t("close"))
        close_btn.clicked.connect(self.hide)
        header.addWidget(close_btn)
        outer.addLayout(header)

        self.image = QLabel("⏳")
        self.image.setFixedHeight(200)
        self.image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image.setStyleSheet(
            f"background: {colors.get('bg','#0e1726')}; border-radius: 12px; color: {colors.get('muted','#999')};"
        )
        self.image.setCursor(Qt.CursorShape.PointingHandCursor)
        self.image.mousePressEvent = self._on_image_click
        outer.addWidget(self.image)

        self.quality_dot = QualityDot()
        outer.addWidget(self.quality_dot)

        self.device_badges = DeviceBadges(colors)
        outer.addWidget(self.device_badges)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(0, 0, 4, 0)
        lay.setSpacing(7)
        scroll.setWidget(body)
        outer.addWidget(scroll, stretch=1)

        self.meta = QLabel()
        self.meta.setWordWrap(True)
        self.meta.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(self.meta)

        section = QLabel(self.tr.t("description").upper())
        section.setObjectName("detailSection")
        lay.addWidget(section)

        self.desc = QLabel()
        self.desc.setObjectName("descBox")
        self.desc.setWordWrap(True)
        self.desc.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        lay.addWidget(self.desc)

        self.more_btn = QPushButton(self.tr.t("read_more"))
        self.more_btn.setObjectName("previewButton")
        self.more_btn.clicked.connect(self._toggle_more)
        lay.addWidget(self.more_btn)

        self.tags_label = QLabel()
        self.tags_label.setWordWrap(True)
        self.tags_label.setObjectName("cardMeta")
        lay.addWidget(self.tags_label)

        lay.addStretch(1)

        # --- przyciski akcji ------------------------------------------------
        actions = QHBoxLayout()
        actions.setSpacing(6)

        self.star_btn = QPushButton("☆")
        self.star_btn.setObjectName("starButton")
        self.star_btn.setFixedWidth(42)
        self.star_btn.clicked.connect(self._on_star)

        self.download_btn = QPushButton("⬇ " + self.tr.t("download"))
        self.download_btn.setObjectName("downloadButton")
        self.download_btn.clicked.connect(self._on_download)

        actions.addWidget(self.star_btn)
        actions.addWidget(self.download_btn, stretch=1)
        outer.addLayout(actions)

        self.source_btn = QPushButton("🔗 " + self.tr.t("source"))
        self.source_btn.setObjectName("previewButton")
        self.source_btn.clicked.connect(self._on_source)
        outer.addWidget(self.source_btn)

        self.browser_btn = QPushButton("🌐 " + self.tr.t("open_in_browser"))
        self.browser_btn.setObjectName("previewButton")
        self.browser_btn.clicked.connect(self._on_browser)
        outer.addWidget(self.browser_btn)

        self.collection_btn = QPushButton("➕ " + self.tr.t("add_to_collection"))
        self.collection_btn.setObjectName("previewButton")
        self.collection_btn.clicked.connect(self._on_collection)
        outer.addWidget(self.collection_btn)

        self.slideshow_btn = QPushButton("▶ " + self.tr.t("slideshow"))
        self.slideshow_btn.setObjectName("downloadButton")
        self.slideshow_btn.clicked.connect(self.slideshow_requested.emit)
        outer.addWidget(self.slideshow_btn)

        self.set_wallpaper(None)

    # --- dane --------------------------------------------------------------
    def set_wallpaper(self, wallpaper: Wallpaper | None, is_fav: bool = False) -> None:
        self.wallpaper = wallpaper
        if wallpaper is None:
            self.title.setText(self.tr.t("details"))
            self.image.setText("🐸")
            self.image.setPixmap(QPixmap())
            self.meta.setText("")
            self.desc.setText("")
            self.tags_label.setText("")
            self.download_btn.setEnabled(False)
            self.source_btn.setEnabled(False)
            self.browser_btn.setEnabled(False)
            self.collection_btn.setEnabled(False)
            self.slideshow_btn.setEnabled(False)
            self.quality_dot.set_quality(Quality.LOW)
            self.device_badges.set_devices([])
            self.more_btn.hide()
            self.star_btn.setText("☆")
            return

        self.title.setText(wallpaper.title[:40])
        self.quality_dot.set_quality(wallpaper.quality)
        self.device_badges.set_devices(wallpaper.devices)
        self._big_key = self.loader.key(wallpaper.thumb_url, BIG_SIZE)
        self.image.setText("⏳")
        self.loader.load(wallpaper.thumb_url, BIG_SIZE)

        rows = [
            ("resolution", wallpaper.resolution),
            ("format", wallpaper.format or "—"),
            ("size", wallpaper.size_text),
            ("quality", self.tr.t("quality_" + wallpaper.quality.value)),
            ("device", (wallpaper.device_icons or "—")),
            ("author", wallpaper.author or "—"),
            ("date", wallpaper.date_text),
            ("rating", str(wallpaper.rating or "—")),
            ("downloads", str(wallpaper.downloads or "—")),
            ("source", wallpaper.source_name or "—"),
        ]
        meta_html = "".join(
            f'<div><span style="color:{self.colors.get("muted","#9db2d4")}">{self.tr.t(k)}:</span> '
            f'<b>{v}</b></div>' for k, v in rows
        )
        self.meta.setText(meta_html)
        full = wallpaper.effective_description()
        fm = QFontMetrics(self.desc.font())
        self._full_text = full
        self._short_text = fm.elidedText(full, Qt.TextElideMode.ElideRight, 300) if len(full) > 140 else full
        self.desc.setText(self._short_text)
        self.more_btn.setVisible(len(full) > 140)
        self.more_btn.setText(self.tr.t("read_more"))
        self.tags_label.setText("  ".join("#" + t for t in wallpaper.tags[:12]))
        self.star_btn.setText("★" if is_fav else "☆")
        self.download_btn.setEnabled(True)
        self.collection_btn.setEnabled(True)
        self.slideshow_btn.setEnabled(True)
        self.source_btn.setEnabled(bool(wallpaper.source_page))
        self.browser_btn.setEnabled(bool(wallpaper.source_page))

    def on_pixmap(self, key: str, pixmap: QPixmap) -> None:
        if key == self._big_key:
            self.image.setPixmap(pixmap)

    # --- akcje -------------------------------------------------------------
    def _on_image_click(self, event) -> None:
        if self.wallpaper is not None:
            self.preview_requested.emit(self.wallpaper)

    def _toggle_more(self) -> None:
        if self.desc.text() == self._short_text:
            self.desc.setText(self._full_text)
            self.more_btn.setText(self.tr.t("close"))
        else:
            self.desc.setText(self._short_text)
            self.more_btn.setText(self.tr.t("read_more"))

    def _on_star(self) -> None:
        if self.wallpaper is not None:
            self.favorite_toggled.emit(self.wallpaper)

    def _on_download(self) -> None:
        if self.wallpaper is not None:
            self.download_clicked.emit(self.wallpaper)

    def _on_source(self) -> None:
        if self.wallpaper is not None and self.wallpaper.source_page:
            QDesktopServices.openUrl(QUrl(self.wallpaper.source_page))

    def _on_browser(self) -> None:
        self._on_source()

    def _on_collection(self) -> None:
        if self.wallpaper is not None:
            self.add_to_collection.emit(self.wallpaper)

    def set_favorite(self, value: bool) -> None:
        self.star_btn.setText("★" if value else "☆")

    def set_colors(self, colors: dict[str, str]) -> None:
        self.colors = colors
        self.device_badges.set_colors(colors)
