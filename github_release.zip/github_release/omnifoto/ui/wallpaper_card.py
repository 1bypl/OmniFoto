"""Kafelki i wiersze listy reprezentujące pojedynczą tapetę."""

from __future__ import annotations

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QFontMetrics
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QMenu, QPushButton, QSizePolicy, QToolButton,
    QVBoxLayout,
)

from ..models import Wallpaper
from .image_loader import ImageLoader
from .widgets import DeviceBadges, QualityDot

THUMB_SIZE = QSize(420, 240)
CARD_WIDTH = 224
CARD_HEIGHT = 322


class WallpaperCardBase:
    """Wspólne pola i logika dla kafelka oraz wiersza listy.

    Sygnały są zadeklarowane w klasach konkretnych (QFrame + mixin), ponieważ
    PySide6 wymaga, aby sygnały należały do klasy dziedziczącej po QObject.
    """

    def _setup_common(self, wallpaper: Wallpaper, loader: ImageLoader, colors: dict[str, str]) -> None:
        self.wallpaper = wallpaper
        self.loader = loader
        self.colors = colors
        self._thumb_key = loader.key(wallpaper.thumb_url, THUMB_SIZE)
        self.loader.pixmap_ready.connect(self._on_pixmap)

    def _elided(self, label: QLabel, text: str) -> None:
        fm = QFontMetrics(label.font())
        label.setText(fm.elidedText(text, Qt.TextElideMode.ElideRight, label.width() - 6))

    def _on_pixmap(self, key: str, pixmap) -> None:
        if key != self._thumb_key:
            return
        target = getattr(self, "image_label", None)
        if target is not None:
            target.setPixmap(pixmap)

    def _load_image(self) -> None:
        pix = self.loader.load(self.wallpaper.thumb_url, THUMB_SIZE)
        if pix is not None:
            self.image_label.setPixmap(pix)

    def _make_buttons(self) -> tuple[QToolButton, QPushButton, QPushButton]:
        gold = self.colors.get("gold", "#ffd54a")
        star = QToolButton()
        star.setObjectName("starButton")
        star.setText("★" if self._is_fav else "☆")
        star.setToolTip("Ulubione")
        star.setStyleSheet(f"color: {gold}; font-size: 20px;")
        star.clicked.connect(self._on_star)

        preview = QPushButton("👁")
        preview.setObjectName("previewButton")
        preview.setFixedWidth(34)
        preview.setToolTip("Podejrzyj w przeglądarce")
        preview.clicked.connect(lambda: self.preview_clicked.emit(self.wallpaper))

        download = QPushButton("⬇ Pobierz")
        download.setObjectName("downloadButton")
        download.setMinimumWidth(82)
        download.setToolTip("Pobierz na dysk")
        download.clicked.connect(lambda: self.download_clicked.emit(self.wallpaper))

        self.star_button = star
        return star, preview, download

    def _on_star(self) -> None:
        self._is_fav = not self._is_fav
        self.star_button.setText("★" if self._is_fav else "☆")
        self.favorite_toggled.emit(self.wallpaper)

    def set_favorite(self, value: bool) -> None:
        self._is_fav = value
        if hasattr(self, "star_button"):
            self.star_button.setText("★" if value else "☆")


class TileCard(QFrame, WallpaperCardBase):
    """Nowoczesny kafelek z miniaturą, metadanymi i przyciskami."""

    preview_clicked = Signal(object)
    download_clicked = Signal(object)
    favorite_toggled = Signal(object)
    add_to_collection = Signal(object)

    def _show_context_menu(self, position) -> None:
        menu = QMenu(self)
        action = menu.addAction("➕ Dodaj do kolekcji")
        chosen = menu.exec(self.mapToGlobal(position))
        if chosen == action:
            self.add_to_collection.emit(self.wallpaper)

    def __init__(self, wallpaper: Wallpaper, loader: ImageLoader,
                 colors: dict[str, str], is_fav: bool = False, parent=None) -> None:
        super().__init__(parent)
        self._setup_common(wallpaper, loader, colors)
        self._is_fav = is_fav
        self.setObjectName("card")
        self.setFixedSize(CARD_WIDTH, CARD_HEIGHT)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(7)

        self.image_label = QLabel()
        self.image_label.setFixedHeight(150)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet(
            f"background: {colors.get('bg', '#0e1726')}; border-radius: 9px; color: {colors.get('muted','#999')};"
        )
        self.image_label.setText("⏳")
        root.addWidget(self.image_label)

        title = QLabel(wallpaper.title[:52])
        title.setObjectName("cardTitle")
        title.setWordWrap(False)
        root.addWidget(title)

        meta = QLabel()
        meta.setObjectName("cardMeta")
        meta.setText(f"{wallpaper.resolution}  •  {wallpaper.format or '—'}  •  {wallpaper.size_text}")
        root.addWidget(meta)

        # czytelne plakietki urządzeń zamiast samych emoji
        self.device_badges = DeviceBadges(colors)
        self.device_badges.set_devices(wallpaper.devices)
        root.addWidget(self.device_badges)

        if wallpaper.special_icons:
            special = QLabel(wallpaper.special_icons)
            special.setObjectName("cardMeta")
            special.setToolTip("Tapeta animowana / wygaszacz ekranu")
            root.addWidget(special)

        # proste, czytelne 🟢 / 🟡 / 🔴 zamiast pulsującego paska
        self.quality_dot = QualityDot(wallpaper.quality)
        root.addWidget(self.quality_dot)

        if wallpaper.tags:
            tag_label = QLabel("  ".join("#" + t[:14] for t in wallpaper.tags[:3]))
            tag_label.setObjectName("cardMeta")
            root.addWidget(tag_label)

        star, preview, download = self._make_buttons()
        row = QHBoxLayout()
        row.setSpacing(6)
        row.addWidget(star)
        row.addWidget(preview, stretch=1)
        row.addWidget(download, stretch=1)
        root.addLayout(row)

        self.image_label.mousePressEvent = lambda e: self.preview_clicked.emit(self.wallpaper)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)
        self._load_image()

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802
        self.preview_clicked.emit(self.wallpaper)


class ListRow(QFrame, WallpaperCardBase):
    """Kompaktowy wiersz - więcej informacji na mniejszej przestrzeni."""

    preview_clicked = Signal(object)
    download_clicked = Signal(object)
    favorite_toggled = Signal(object)
    add_to_collection = Signal(object)

    def _show_context_menu(self, position) -> None:
        menu = QMenu(self)
        action = menu.addAction("➕ Dodaj do kolekcji")
        chosen = menu.exec(self.mapToGlobal(position))
        if chosen == action:
            self.add_to_collection.emit(self.wallpaper)

    def __init__(self, wallpaper: Wallpaper, loader: ImageLoader,
                 colors: dict[str, str], is_fav: bool = False, parent=None) -> None:
        super().__init__(parent)
        self._setup_common(wallpaper, loader, colors)
        self._is_fav = is_fav
        self.setObjectName("card")
        self.setFixedHeight(104)

        root = QHBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(12)

        self.image_label = QLabel()
        self.image_label.setFixedSize(140, 84)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet(
            f"background: {colors.get('bg', '#0e1726')}; border-radius: 8px; color: {colors.get('muted','#999')};"
        )
        self.image_label.setText("⏳")
        root.addWidget(self.image_label)

        middle = QVBoxLayout()
        middle.setSpacing(3)
        title = QLabel(wallpaper.title[:80])
        title.setObjectName("cardTitle")
        middle.addWidget(title)
        meta = QLabel(
            f"{wallpaper.resolution}  •  {wallpaper.format or '—'}  •  {wallpaper.size_text}  •  "
            f"{wallpaper.source_name}  •  {wallpaper.date_text}  •  ⭐ {wallpaper.rating or '—'}"
        )
        meta.setObjectName("cardMeta")
        middle.addWidget(meta)
        self.device_badges = DeviceBadges(colors)
        self.device_badges.set_devices(wallpaper.devices)
        middle.addWidget(self.device_badges)

        extra = QLabel((wallpaper.special_icons + "   " + "  ".join("#" + t[:12] for t in wallpaper.tags[:4])).strip())
        extra.setObjectName("cardMeta")
        middle.addWidget(extra)
        root.addLayout(middle, stretch=1)

        right = QVBoxLayout()
        right.setSpacing(5)
        self.quality_dot = QualityDot(wallpaper.quality)
        right.addWidget(self.quality_dot)
        star, preview, download = self._make_buttons()
        btns = QHBoxLayout()
        btns.setSpacing(5)
        btns.addWidget(star)
        btns.addWidget(preview)
        btns.addWidget(download)
        right.addLayout(btns)
        root.addLayout(right)

        self.image_label.mousePressEvent = lambda e: self.preview_clicked.emit(self.wallpaper)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)
        self._load_image()
