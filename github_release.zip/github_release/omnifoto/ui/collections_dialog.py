"""Okno zarządzania własnymi kolekcjami tapet (import, eksport, usuwanie)."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QImageReader, QPixmap
from PySide6.QtWidgets import (
    QDialog, QFileDialog, QHBoxLayout, QInputDialog, QLabel, QListWidget,
    QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout,
)

from ..models import Wallpaper


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp", ".avif", ".heic", ".heif", ".svg", ".bmp", ".gif"}


def _wallpaper_dict(entry) -> dict | None:
    try:
        if isinstance(entry, Wallpaper):
            return entry.to_dict()
        if isinstance(entry, dict):
            return Wallpaper.from_dict(entry).to_dict()
    except Exception:
        return None
    return None


def wallpaper_from_image(path: Path) -> dict | None:
    """Tworzy wpis tapety z lokalnego pliku graficznego."""
    if path.suffix.lower() not in IMAGE_SUFFIXES or not path.is_file():
        return None
    try:
        reader = QImageReader(str(path))
        size = reader.size()
        w, h = size.width(), size.height()
        if w <= 0 or h <= 0:
            pix = QPixmap(str(path))
            w, h = pix.width(), pix.height()
        file_size = path.stat().st_size
    except Exception:
        return None
    resolved = str(path.resolve())
    return {
        "id": hashlib.sha1(resolved.encode("utf-8", "ignore")).hexdigest()[:16],
        "title": path.stem.replace("_", " ").replace("-", " ")[:90] or path.name,
        "url": resolved,
        "thumb_url": resolved,
        "source_page": "",
        "source_name": "Lokalny plik",
        "width": w, "height": h,
        "format": path.suffix.lower().lstrip(".").upper(),
        "file_size": file_size,
        "author": "",
        "published": datetime.now(timezone.utc).isoformat(),
        "rating": None, "downloads": None,
        "tags": [path.parent.name] if path.parent.name else [],
        "description": f"Dodane lokalnie: {path.name}",
        "category": "", "devices": [], "colors": [],
        "is_animated": path.suffix.lower() in (".gif", ".webp"),
        "is_screensaver": False,
        "source_kind": "local",
    }


def images_from_paths(paths) -> list[dict]:
    """Zbiera wpisy z listy plików i/lub całych folderów."""
    out: list[dict] = []
    seen: set[str] = set()
    for raw in paths:
        p = Path(raw)
        candidates = [c for c in p.rglob("*") if c.is_file()] if p.is_dir() else [p]
        for candidate in candidates:
            entry = wallpaper_from_image(candidate)
            if entry and entry["url"] not in seen:
                seen.add(entry["url"])
                out.append(entry)
    return out


class CollectionsDialog(QDialog):
    collections_changed = Signal()
    show_requested = Signal(object, str)

    def __init__(self, translator, settings, parent=None) -> None:
        super().__init__(parent)
        self.tr = translator
        self.settings = settings
        self.setWindowTitle(self.tr.t("collections"))
        self.resize(720, 500)
        self._selected_id: str | None = None

        root = QVBoxLayout(self)
        body = QHBoxLayout()

        # --- lewa strona: lista kolekcji -----------------------------------
        left = QVBoxLayout()
        left.addWidget(QLabel(self.tr.t("collections")))
        self.list = QListWidget()
        self.list.currentItemChanged.connect(self._on_select)
        left.addWidget(self.list)
        btn_row = QHBoxLayout()
        new_btn = QPushButton("＋ " + self.tr.t("new_collection"))
        import_btn = QPushButton("📥 " + self.tr.t("import_collection"))
        export_btn = QPushButton("📤 " + self.tr.t("export_collection"))
        del_btn = QPushButton("－ " + self.tr.t("delete_collection"))
        new_btn.clicked.connect(self._new)
        import_btn.clicked.connect(self._import)
        export_btn.clicked.connect(self._export)
        del_btn.clicked.connect(self._delete)
        for b in (new_btn, import_btn, export_btn, del_btn):
            b.setObjectName("previewButton")
            btn_row.addWidget(b)
        left.addLayout(btn_row)

        # pliki graficzne i całe foldery (bez pośrednictwa JSON)
        file_row = QHBoxLayout()
        folder_btn = QPushButton("📁 Nowa z folderu")
        add_files_btn = QPushButton("🖼 Dodaj pliki/folder")
        folder_btn.clicked.connect(self._new_from_folder)
        add_files_btn.clicked.connect(self._add_files)
        for b in (folder_btn, add_files_btn):
            b.setObjectName("downloadButton")
            file_row.addWidget(b)
        left.addLayout(file_row)
        body.addLayout(left, stretch=1)

        # --- prawa strona: zawartość kolekcji -------------------------------
        right = QVBoxLayout()
        self.title = QLabel("—")
        self.title.setObjectName("detailTitle")
        right.addWidget(self.title)
        self.items_list = QListWidget()
        right.addWidget(self.items_list)
        item_btns = QHBoxLayout()
        show_btn = QPushButton("👁 " + self.tr.t("show_collection"))
        remove_item = QPushButton("－ Usuń tapetę")
        show_btn.setObjectName("downloadButton")
        remove_item.setObjectName("previewButton")
        show_btn.clicked.connect(self._show)
        remove_item.clicked.connect(self._remove_item)
        item_btns.addWidget(show_btn)
        item_btns.addWidget(remove_item)
        right.addLayout(item_btns)
        body.addLayout(right, stretch=2)

        root.addLayout(body)
        close = QPushButton(self.tr.t("close"))
        close.clicked.connect(self.accept)
        root.addWidget(close)
        self._fill()

    # --- dane --------------------------------------------------------------
    def _fill(self, select_id: str | None = None) -> None:
        self.list.clear()
        collections = self.settings.collections()
        for col in collections:
            item = QListWidgetItem(f"📚 {col.get('name','')}  ({len(col.get('items', []))})")
            item.setData(Qt.ItemDataRole.UserRole, col.get("id"))
            self.list.addItem(item)
        if collections:
            target = select_id or self._selected_id
            for i in range(self.list.count()):
                if self.list.item(i).data(Qt.ItemDataRole.UserRole) == target:
                    self.list.setCurrentRow(i)
                    break
            if self.list.currentRow() < 0:
                self.list.setCurrentRow(0)
        else:
            self.title.setText(self.tr.t("collection_empty"))
            self.items_list.clear()

    def _current_collection(self) -> dict | None:
        item = self.list.currentItem()
        if not item:
            return None
        cid = item.data(Qt.ItemDataRole.UserRole)
        return next((c for c in self.settings.collections() if c.get("id") == cid), None)

    def _on_select(self) -> None:
        col = self._current_collection()
        self.items_list.clear()
        if not col:
            self.title.setText("—")
            return
        self._selected_id = col.get("id")
        self.title.setText(f"📚 {col.get('name','')} — {len(col.get('items', []))} tapet")
        for entry in col.get("items", []):
            w = Wallpaper.from_dict(entry) if isinstance(entry, dict) else None
            if w is None:
                continue
            it = QListWidgetItem(f"{w.resolution} • {w.format or '—'} • {w.title[:48]}")
            it.setData(Qt.ItemDataRole.UserRole, w.id)
            it.setToolTip(w.effective_description()[:240])
            self.items_list.addItem(it)

    # --- akcje -------------------------------------------------------------
    def _new(self) -> None:
        name, ok = QInputDialog.getText(self, self.tr.t("new_collection"), self.tr.t("collection_name"))
        if ok and name.strip():
            col = self.settings.add_collection(name)
            self._fill(col["id"])
            self.collections_changed.emit()

    def _delete(self) -> None:
        col = self._current_collection()
        if not col:
            return
        if QMessageBox.question(self, self.tr.t("confirm_remove"), col.get("name", "")) == QMessageBox.StandardButton.Yes:
            self.settings.remove_collection(col["id"])
            self._selected_id = None
            self._fill()
            self.collections_changed.emit()

    def _new_from_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Wybierz folder z tapetami")
        if not folder:
            return
        items = images_from_paths([folder])
        if not items:
            QMessageBox.information(self, self.tr.t("collections"), "Nie znaleziono plików graficznych w tym folderze.")
            return
        col = self.settings.add_collection(Path(folder).name or "Kolekcja", items)
        self._fill(col["id"])
        self.collections_changed.emit()

    def _add_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(
            self, "Dodaj pliki graficzne", "",
            "Obrazy (*.jpg *.jpeg *.png *.webp *.avif *.bmp *.gif *.svg)",
        )
        paths = list(files)
        if not paths:
            folder = QFileDialog.getExistingDirectory(self, "Lub wybierz cały folder")
            if folder:
                paths = [folder]
        if not paths:
            return
        items = images_from_paths(paths)
        if not items:
            QMessageBox.information(self, self.tr.t("collections"), "Nie znaleziono obsługiwanych plików graficznych.")
            return
        col = self._current_collection()
        if not col:
            name, ok = QInputDialog.getText(self, self.tr.t("new_collection"), self.tr.t("collection_name"))
            if not ok or not name.strip():
                return
            col = self.settings.add_collection(name.strip(), items)
        else:
            for entry in items:
                self.settings.add_to_collection(col["id"], entry)
        self._fill(col["id"])
        self.collections_changed.emit()

    def _import(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.tr.t("import_collection"), "", "JSON (*.json)")
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("collections"), list):
                for col in data["collections"]:
                    items = [d for d in (_wallpaper_dict(e) for e in col.get("items", [])) if d]
                    self.settings.add_collection(col.get("name", "Import"), items)
                name = ", ".join(c.get("name", "") for c in data["collections"])
            elif isinstance(data, dict) and "items" in data:
                items = [d for d in (_wallpaper_dict(e) for e in data["items"]) if d]
                self.settings.add_collection(data.get("name", "Import"), items)
                name = data.get("name", "Import")
            elif isinstance(data, list):
                items = [d for d in (_wallpaper_dict(e) for e in data) if d]
                self.settings.add_collection(Path(path).stem, items)
                name = Path(path).stem
            else:
                raise ValueError("Nieznany format pliku")
            self._fill()
            self.collections_changed.emit()
            QMessageBox.information(self, self.tr.t("import_collection"),
                                    self.tr.t("import_done", name=name))
        except Exception as exc:
            QMessageBox.warning(self, self.tr.t("import_collection"), str(exc))

    def _export(self) -> None:
        col = self._current_collection()
        if not col:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, self.tr.t("export_collection"), col.get("name", "kolekcja") + ".json", "JSON (*.json)"
        )
        if not path:
            return
        try:
            Path(path).write_text(
                json.dumps({"name": col.get("name", ""), "items": col.get("items", [])},
                           indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError as exc:
            QMessageBox.warning(self, self.tr.t("export_collection"), str(exc))

    def _show(self) -> None:
        col = self._current_collection()
        if not col:
            return
        items = []
        for entry in col.get("items", []):
            try:
                items.append(Wallpaper.from_dict(entry))
            except Exception:
                continue
        if items:
            self.show_requested.emit(items, col.get("name", ""))

    def _remove_item(self) -> None:
        col = self._current_collection()
        item = self.items_list.currentItem()
        if not col or not item:
            return
        wid = item.data(Qt.ItemDataRole.UserRole)
        collections = self.settings.collections()
        for c in collections:
            if c.get("id") == col.get("id"):
                c["items"] = [i for i in c.get("items", []) if not (isinstance(i, dict) and i.get("id") == wid)]
                break
        self.settings.set("collections", collections)
        if not self.settings.privacy_mode:
            self.settings.save()
        self._on_select()
        self.collections_changed.emit()


def choose_collection(translator, settings, parent=None) -> str | None:
    """Pokazuje prosty wybór kolekcji. Zwraca id kolekcji albo None."""
    collections = settings.collections()
    if not collections:
        QMessageBox.information(parent, translator.t("collections"),
                                "Nie masz jeszcze kolekcji. Utwórz ją w menu 📚 Kolekcje.")
        return None
    names = [c.get("name", "") for c in collections]
    name, ok = QInputDialog.getItem(
        parent, translator.t("add_to_collection"), translator.t("collection_name"), names, 0, False
    )
    if not ok:
        return None
    return next((c.get("id") for c in collections if c.get("name") == name), None)
