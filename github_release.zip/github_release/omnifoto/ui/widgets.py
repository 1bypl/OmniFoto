"""Małe, animowane kontrolki: pulsujący pasek jakości, postęp i licznik."""

from __future__ import annotations

import math

from PySide6.QtCore import QRectF, QTimer, Qt, Signal
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout

from ..constants import DEVICE_BADGE, QUALITY_EMOJI, QUALITY_LABEL
from ..models import Quality


def _mix(c1: QColor, c2: QColor, t: float) -> QColor:
    t = max(0.0, min(1.0, t))
    return QColor(
        int(c1.red() + (c2.red() - c1.red()) * t),
        int(c1.green() + (c2.green() - c1.green()) * t),
        int(c1.blue() + (c2.blue() - c1.blue()) * t),
    )


def _rounded(painter: QPainter, rect: QRectF, radius: float) -> None:
    painter.drawRoundedRect(rect, radius, radius)


class QualityDot(QLabel):
    """Czytelny wskaźnik jakości: 🟢 / 🟡 / 🔴 zamiast pulsującego paska."""

    def __init__(self, quality: Quality = Quality.LOW, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("cardMeta")
        self.set_quality(quality)

    def set_quality(self, quality: Quality) -> None:
        self._quality = quality
        self.setText(f"{QUALITY_EMOJI[quality.value]}  {QUALITY_LABEL[quality.value]}")
        self.setToolTip("Jakość/rozdzielczość: " + QUALITY_LABEL[quality.value])


class DeviceBadges(QFrame):
    """Czytelne plakietki urządzeń: 🖥 PC, 💻 LAP, 📱 TEL, 📟 TAB."""

    def __init__(self, colors: dict[str, str] | None = None, parent=None) -> None:
        super().__init__(parent)
        self.colors = colors or {}
        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(4)
        self._layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.set_devices([])

    def set_colors(self, colors: dict[str, str]) -> None:
        self.colors = colors
        if getattr(self, "_devices", None):
            self.set_devices(self._devices)

    def set_devices(self, devices) -> None:
        self._devices = list(devices or [])
        while self._layout.count():
            item = self._layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
        if not self._devices:
            return
        border = self.colors.get("border", "#2c4470")
        panel = self.colors.get("panel", "#1b2b47")
        text = self.colors.get("text", "#e8f0ff")
        for device in self._devices:
            key = getattr(device, "value", str(device))
            icon, short, full = DEVICE_BADGE.get(key, ("•", "?", "Nieznane urządzenie"))
            badge = QLabel(f"{icon} {short}")
            badge.setToolTip(full)
            badge.setStyleSheet(
                f"background:{panel}; color:{text}; border:1px solid {border};"
                "border-radius:6px; padding:1px 5px; font-size:10px; font-weight:600;"
            )
            self._layout.addWidget(badge)
        self._layout.addStretch(1)


class SearchProgressWidget(QFrame):
    """Elegancki pasek postępu z czasem, wynikami per źródło i sumą."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._accent = "#3b9dff"
        self._muted = "#9db2d4"
        self._elapsed = 0.0
        self._total = 0
        self._sources: dict[str, tuple[int, bool]] = {}
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        self.info = QLabel("")
        self.info.setObjectName("hint")
        self.info.setWordWrap(False)
        self.info.setFixedHeight(18)
        self.info.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        lay.addWidget(self.info, stretch=1)
        self.strip = ProgressStrip()
        self.strip.setFixedSize(120, 3)
        lay.addWidget(self.strip)

    def set_colors(self, colors: dict[str, str]) -> None:
        self._accent = colors.get("accent", "#3b9dff")
        self._muted = colors.get("muted", "#9db2d4")
        self.strip.set_colors(colors)

    def set_active(self, active: bool) -> None:
        self.strip.set_active(active)

    def reset(self) -> None:
        self._elapsed = 0.0
        self._total = 0
        self._sources = {}
        self.info.setText("")

    def set_elapsed(self, seconds: float) -> None:
        self._elapsed = seconds
        self._refresh()

    def set_total(self, total: int) -> None:
        self._total = total
        self._refresh()

    def set_source_progress(self, name: str, count: int, ok: bool) -> None:
        self._sources[name] = (count, ok)
        self._total = sum(c for c, _ in self._sources.values())
        self._refresh()

    def set_message(self, text: str) -> None:
        self.info.setText(text)

    def _refresh(self) -> None:
        details = []
        for name, (count, ok) in list(self._sources.items())[:6]:
            icon = "✅" if ok else "⏭️"
            details.append(f"{icon} {name}: <b>{count}</b>")
        source_text = " &nbsp;•&nbsp; ".join(details) if details else "—"
        self.info.setText(
            f'<span style="color:{self._accent}">⏱ {self._elapsed:.1f}s</span>'
            f' &nbsp;•&nbsp; {source_text}'
            f' &nbsp;•&nbsp; Łącznie: <b style="color:{self._accent}">{self._total}</b>'
        )


class PulseBar(QFrame):
    """Kolorowy, pulsujący pasek informujący o jakości/rozdzielczości tapety.

    zielony = wysoka rozdzielczość, żółty = średnia, czerwony = niska.
    Kolor bazowy (tło paska) pochodzi z aktywnego motywu.
    """

    def __init__(self, parent=None, colors: dict[str, str] | None = None) -> None:
        super().__init__(parent)
        self.setFixedHeight(7)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.colors = colors or {}
        self._quality = Quality.LOW
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(45)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def set_quality(self, quality: Quality) -> None:
        self._quality = quality

    def set_colors(self, colors: dict[str, str]) -> None:
        self.colors = colors

    def stop(self) -> None:
        self._timer.stop()

    def _tick(self) -> None:
        self._phase = (self._phase + 0.09) % (2 * math.pi)
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(1, 1, self.width() - 2, self.height() - 2)
        base = QColor(self.colors.get("border", "#2c4470"))
        target_hex = self.colors.get(self._quality.value, "#e74c3c")
        target = QColor(target_hex)
        wave = (math.sin(self._phase) + 1.0) / 2.0
        current = _mix(base, target, 0.45 + 0.55 * wave)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(base)
        _rounded(painter, rect, rect.height() / 2)

        fill_w = rect.width() * (0.35 + 0.65 * wave)
        fill = QRectF(rect.x(), rect.y(), fill_w, rect.height())
        grad = QLinearGradient(fill.x(), 0, fill.x() + max(fill.width(), 1), 0)
        grad.setColorAt(0.0, _mix(base, target, 0.25))
        grad.setColorAt(1.0, current)
        painter.setBrush(grad)
        _rounded(painter, fill, rect.height() / 2)

        # delikatna poświata
        pen = QPen(QColor(current.red(), current.green(), current.blue(), 90))
        pen.setWidth(1)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        _rounded(painter, rect.adjusted(0.5, 0.5, -0.5, -0.5), rect.height() / 2)


class ProgressStrip(QFrame):
    """Aktywny pasek w kolorze skórki - pokazuje postęp przeszukiwania źródeł."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedHeight(3)
        self._active = False
        self._offset = 0
        self._accent = QColor("#3b9dff")
        self._timer = QTimer(self)
        self._timer.setInterval(40)
        self._timer.timeout.connect(self._tick)

    def set_colors(self, colors: dict[str, str]) -> None:
        self._accent = QColor(colors.get("accent", "#3b9dff"))

    def set_active(self, active: bool) -> None:
        self._active = active
        if active:
            self._timer.start()
        else:
            self._timer.stop()
            self.update()

    def _tick(self) -> None:
        self._offset = (self._offset + 6) % 120
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(0, 0, self.width(), self.height())
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(self._accent.red(), self._accent.green(), self._accent.blue(), 45))
        painter.drawRoundedRect(rect, 2, 2)
        if self._active:
            seg_w = max(40, self.width() // 3)
            x = (self._offset / 120.0) * (self.width() + seg_w) - seg_w
            seg = QRectF(x, 0, seg_w, rect.height())
            grad = QLinearGradient(seg.x(), 0, seg.x() + seg.width(), 0)
            grad.setColorAt(0.0, QColor(self._accent.red(), self._accent.green(), self._accent.blue(), 0))
            grad.setColorAt(0.5, self._accent)
            grad.setColorAt(1.0, QColor(self._accent.red(), self._accent.green(), self._accent.blue(), 0))
            painter.setBrush(grad)
            painter.drawRoundedRect(seg, 2, 2)


class Spinner(QLabel):
    """Mała, obracająca się ikonka aktywności (kolor z motywu)."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedSize(20, 20)
        self._angle = 0
        self._active = False
        self._accent = QColor("#3b9dff")
        self._timer = QTimer(self)
        self._timer.setInterval(45)
        self._timer.timeout.connect(self._tick)

    def set_colors(self, colors: dict[str, str]) -> None:
        self._accent = QColor(colors.get("accent", "#3b9dff"))

    def set_active(self, active: bool) -> None:
        self._active = active
        if active:
            self._timer.start()
        else:
            self._timer.stop()
        self.update()

    def _tick(self) -> None:
        self._angle = (self._angle + 22) % 360
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        if not self._active:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        faint = QColor(self._accent.red(), self._accent.green(), self._accent.blue(), 45)
        painter.setBrush(faint)
        painter.drawEllipse(1, 1, 18, 18)
        pen = QPen(self._accent)
        pen.setWidth(3)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawArc(2, 2, 16, 16, -self._angle * 16, 110 * 16)


class AnimatedCounter(QLabel):
    """Licznik z animowanym „dobijaniem” do liczby wyników."""

    arrived = Signal()

    def __init__(self, parent=None, template: str = "Znaleziono {n} wyników z {s} źródeł") -> None:
        super().__init__(parent)
        self.setObjectName("counter")
        self.template = template
        self._target = 0
        self._sources = 0
        self._current = 0
        self._timer = QTimer(self)
        self._timer.setInterval(28)
        self._timer.timeout.connect(self._tick)

    def set_template(self, template: str) -> None:
        self.template = template

    def set_counts(self, results: int, sources: int) -> None:
        self._target = results
        self._sources = sources
        if results == 0:
            self._current = 0
            self.setText(self.template.format(n=0, s=sources))
            self._timer.stop()
            return
        self._timer.start()

    def _tick(self) -> None:
        diff = self._target - self._current
        if diff <= 0:
            self._current = self._target
            self._timer.stop()
            self.arrived.emit()
        else:
            self._current += max(1, int(diff * 0.18))
        self.setText(self.template.format(n=self._current, s=self._sources))

    def stop(self) -> None:
        self._timer.stop()
