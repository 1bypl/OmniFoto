"""Widok wyników: kafelki albo lista, z pustym stanem i obsługą kart."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QLabel, QScrollArea, QVBoxLayout, QWidget

from ..models import ViewMode, Wallpaper
from .flow_layout import FlowLayout
from .image_loader import ImageLoader
from .wallpaper_card import ListRow, TileCard


class ResultsView(QScrollArea):
    preview_clicked = Signal(object)
    download_clicked = Signal(object)
    favorite_toggled = Signal(object)
    add_to_collection = Signal(object)

    def __init__(self, translator, loader: ImageLoader, colors: dict[str, str],
                 favorites: set[str], parent=None) -> None:
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.tr = translator
        self.loader = loader
        self.colors = colors
        self.favorites = favorites
        self.mode = ViewMode.TILES
        self.context = "home"
        self._items: list[Wallpaper] = []
        self._cards: list = []

        host = QWidget()
        root = QVBoxLayout(host)
        root.setContentsMargins(2, 2, 2, 2)

        self._tiles_widget = QWidget()
        self._flow = FlowLayout(self._tiles_widget, margin=10, spacing=16)
        root.addWidget(self._tiles_widget)

        self._list_widget = QWidget()
        self._list = QVBoxLayout(self._list_widget)
        self._list.setContentsMargins(10, 10, 10, 10)
        self._list.setSpacing(8)
        self._list.addStretch(1)
        root.addWidget(self._list_widget)
        self._list_widget.hide()

        self._empty = QLabel()
        self._empty.setObjectName("emptyState")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setWordWrap(True)
        root.addWidget(self._empty)
        self._empty.hide()

        self.setWidget(host)
        self._apply_mode_visibility()

    # --- dane --------------------------------------------------------------
    def set_wallpapers(self, items: list[Wallpaper]) -> None:
        self.clear()
        self._items = list(items)
        for w in self._items:
            self._add_card(w)
        self._update_empty()

    def append_wallpapers(self, items: list[Wallpaper]) -> None:
        for w in items:
            self._add_card(w)
        self._items.extend(items)
        self._update_empty()

    def _add_card(self, w: Wallpaper) -> None:
        is_fav = w.id in self.favorites
        if self.mode == ViewMode.TILES:
            card = TileCard(w, self.loader, self.colors, is_fav)
            self._flow.addWidget(card)
        else:
            card = ListRow(w, self.loader, self.colors, is_fav)
            self._list.insertWidget(self._list.count() - 1, card)
        card.preview_clicked.connect(self.preview_clicked.emit)
        card.download_clicked.connect(self.download_clicked.emit)
        card.favorite_toggled.connect(self.favorite_toggled.emit)
        card.add_to_collection.connect(self.add_to_collection.emit)
        self._cards.append(card)

    def clear(self) -> None:
        self._flow.clear()
        while self._list.count() > 1:  # ostatni element to stretch
            item = self._list.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
        self._cards.clear()
        self._items.clear()

    def set_mode(self, mode: ViewMode) -> None:
        if mode == self.mode:
            return
        items = list(self._items)
        self.clear()
        self.mode = mode
        self._apply_mode_visibility()
        for w in items:
            self._add_card(w)
        self._update_empty()

    def _apply_mode_visibility(self) -> None:
        tiles = self.mode == ViewMode.TILES
        self._tiles_widget.setVisible(tiles)
        self._list_widget.setVisible(not tiles)

    def set_colors(self, colors: dict[str, str]) -> None:
        """Zapisuje nową paletę; karty są odświeżane przez MainWindow."""
        self.colors = colors

    def set_favorite_state(self, wallpaper_id: str, value: bool) -> None:
        for card in self._cards:
            w = getattr(card, "wallpaper", None)
            if w is not None and w.id == wallpaper_id:
                card.set_favorite(value)

    def _update_empty(self) -> None:
        if self._items:
            self._empty.hide()
            self._tiles_widget.show() if self.mode == ViewMode.TILES else self._list_widget.show()
            return
        text = {
            "home": self.tr.t("welcome_title") + "\n\n" + self.tr.t("welcome_text"),
            "favorites": self.tr.t("no_favorites"),
            "recent": self.tr.t("no_recent"),
            "collections": self.tr.t("collection_empty"),
        }.get(self.context, self.tr.t("no_results"))
        self._empty.setText(text)
        self._empty.show()
        self._tiles_widget.hide()
        self._list_widget.hide()

    def set_context(self, context: str) -> None:
        self.context = context
        self._update_empty()

    def set_theme_hint(self, text: str) -> None:
        self._empty.setText(text)

    @property
    def wallpapers(self) -> list[Wallpaper]:
        return list(self._items)
