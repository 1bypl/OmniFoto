"""Główne okno OmniFoto - łączy wszystkie komponenty i przepływ danych."""

from __future__ import annotations

from pathlib import Path
from threading import Event

from PySide6.QtCore import QElapsedTimer, QObject, QThread, QTimer, Qt, Signal
from PySide6.QtGui import QCloseEvent, QKeyEvent
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QMainWindow, QMessageBox,
    QSplitter, QVBoxLayout, QWidget,
)

from .. import __version__, APP_NAME
from ..models import DeviceType, SortKey, TimeRange, ViewMode, Wallpaper
from ..privacy import PrivacySession
from ..search import SearchManager
from ..settings import Settings
from ..utils import (
    filter_by_category, filter_by_time, prepare_query, relevance_score,
    safe_filename, sort_wallpapers,
)
from ..constants import THEME_CYCLE_ORDER
from .collections_dialog import CollectionsDialog, choose_collection
from .dialogs import AboutDialog, SettingsDialog
from .detail_panel import DetailPanel
from .image_loader import ImageLoader
from .results_view import ResultsView
from .search_bar import SearchBar
from .sidebar import Sidebar
from .slideshow import Slideshow
from .theme import apply_theme, theme_colors


class SearchWorker(QObject):
    """Praca w tle - wyszukiwanie nie blokuje interfejsu."""

    finished = Signal(object, int)
    progress = Signal(str, int, bool, int)

    def __init__(self, manager: SearchManager, params: dict, gen: int = 0,
                 cancel: Event | None = None) -> None:
        super().__init__()
        self.manager = manager
        self.params = params
        self.gen = gen
        self.cancel = cancel or Event()

    def run(self) -> None:
        try:
            result = self.manager.search(
                progress=lambda name, n, ok: self.progress.emit(name, n, ok, self.gen),
                cancel=self.cancel,
                **self.params,
            )
        except Exception as exc:
            result = None
            self.progress.emit("Błąd", 0, False)
            self.error_text = str(exc)
        else:
            self.error_text = ""
        self.finished.emit(result, self.gen)


class DownloadWorker(QObject):
    """Pobieranie pliku w tle, bez zapisywania czegokolwiek innego."""

    finished = Signal(object)   # (ok: bool, wiadomość: str)

    def __init__(self, session: PrivacySession, url: str, path: Path) -> None:
        super().__init__()
        self.session = session
        self.url = url
        self.path = path

    def run(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            source = Path(self.url)
            if source.is_file():
                data = source.read_bytes()  # tapeta z własnej kolekcji
            else:
                data = self.session.request(self.url)
            self.path.write_bytes(data)
            self.finished.emit((True, str(self.path)))
        except Exception as exc:
            self.finished.emit((False, str(exc)))


class MainWindow(QMainWindow):
    def __init__(self, app: QApplication, translator, settings: Settings) -> None:
        super().__init__()
        self.app = app
        self.tr = translator
        self.settings = settings
        self.colors = theme_colors(settings.get("theme", "azureus"))
        self.session = PrivacySession(settings, timeout=6)
        self.loader = ImageLoader()
        self.loader.set_user_agent(self.session.user_agent)
        self.manager = SearchManager(self.session, settings)

        self.current_query = ""
        self._last_search = None
        self.current_category = "all"
        self.current_results: list[Wallpaper] = []
        self.context = "home"
        self._thread: QThread | None = None
        self._worker: QObject | None = None
        self._favorites: dict[str, Wallpaper] = {}
        self._history: dict[str, Wallpaper] = {}
        self._load_local_collections()

        self.setWindowTitle(f"{APP_NAME} {__version__} — lokalna przeglądarka tapet")
        self.resize(1360, 860)
        self.setMinimumSize(820, 560)
        self._search_gen = 0
        self._active_searches: list = []
        self._elapsed = QElapsedTimer()
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(100)
        self._elapsed_timer.timeout.connect(self._tick_elapsed)
        self._detail_was_visible = False
        self._build_ui()
        self._connect()
        self._apply_all_theme()
        self.results.set_context("home")
        self.show()

    # --- budowa interfejsu -------------------------------------------------
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        self.sidebar = Sidebar(self.tr, self.settings)
        body.addWidget(self.sidebar)

        center = QWidget()
        center_layout = QVBoxLayout(center)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)

        self.search_bar = SearchBar(self.tr, self.settings)
        # KLUCZOWE: sztywna wysokość w pionie + stretch 0. Bez tego Qt
        # rozciąga wyszukiwarkę na połowę okna i zasłania kafelki.
        from PySide6.QtWidgets import QSizePolicy
        self.search_bar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        center_layout.addWidget(self.search_bar, 0)

        workspace = QSplitter(Qt.Orientation.Horizontal)
        self.results = ResultsView(
            self.tr, self.loader, self.colors, set(self._favorites.keys())
        )
        self.detail = DetailPanel(self.tr, self.loader, self.colors)
        workspace.addWidget(self.results)
        workspace.addWidget(self.detail)
        workspace.setStretchFactor(0, 1)
        workspace.setStretchFactor(1, 0)
        self.detail.hide()
        self.workspace = workspace
        center_layout.addWidget(workspace, 1)
        body.addWidget(center, stretch=1)
        root.addLayout(body)

        self.slideshow = Slideshow(self.tr, self.loader, self.colors)
        self.slideshow.set_favorite(False)

        self.loader.pixmap_ready.connect(self.detail.on_pixmap)
        self.loader.pixmap_ready.connect(self.slideshow.on_pixmap)

    def _connect(self) -> None:
        self.sidebar.nav_clicked.connect(self._on_nav)
        self.sidebar.category_clicked.connect(self._on_category)
        self.sidebar.collection_opened.connect(self.open_collection_by_name)
        self.search_bar.search_requested.connect(self.start_search)
        self.search_bar.sort_changed.connect(self._on_sort_changed)
        self.search_bar.time_changed.connect(self._on_time_changed)
        self.search_bar.view_changed.connect(self._on_view_changed)
        self.search_bar.favorite_filter_toggled.connect(self._on_fav_filter)
        self.search_bar.slideshow_requested.connect(self.open_slideshow)

        self.results.preview_clicked.connect(self.preview_wallpaper)
        self.results.download_clicked.connect(self.download_wallpaper)
        self.results.favorite_toggled.connect(self.toggle_favorite)
        self.results.add_to_collection.connect(self.add_to_collection)

        self.detail.preview_requested.connect(self.preview_wallpaper)
        self.detail.download_clicked.connect(self.download_wallpaper)
        self.detail.favorite_toggled.connect(self.toggle_favorite)
        self.detail.add_to_collection.connect(self.add_to_collection)
        self.detail.slideshow_requested.connect(self.open_slideshow_at_detail)

        self.slideshow.favorite_toggled.connect(self.toggle_favorite)
        self.slideshow.download_clicked.connect(self.download_wallpaper)
        self.search_bar.theme_cycle_clicked.connect(self.cycle_theme)
        self.search_bar.more_requested.connect(self._load_more)
        self.search_bar.refresh_requested.connect(self._refresh_search)

    # --- dane lokalne ------------------------------------------------------
    def _load_local_collections(self) -> None:
        for entry in self.settings.get("favorites", []):
            try:
                w = Wallpaper.from_dict(entry) if isinstance(entry, dict) else None
                if w is not None:
                    self._favorites[w.id] = w
            except Exception:
                continue
        for entry in self.settings.get("history", []):
            try:
                w = Wallpaper.from_dict(entry) if isinstance(entry, dict) else None
                if w is not None:
                    self._history[w.id] = w
            except Exception:
                continue

    def _sync_favorite_set(self) -> None:
        self.results.favorites = set(self._favorites.keys())

    # --- wyszukiwanie ------------------------------------------------------
    def start_search(self, query: str, best: bool = False, category: str | None = None,
                     limit: int | None = None) -> None:
        # Każde wyszukiwanie dostaje własny wątek i numer. Dzięki temu nowe
        # zapytanie nigdy nie jest blokowane przez poprzednie, a przestarzałe
        # wyniki są po cichu odrzucane.
        # Anuluj poprzednie wyszukiwania: inaczej przy szybkim wpisywaniu
        # kilka wątków jednocześnie dławi sieć i interfejs się zawiesza.
        for thread, worker, _old_gen in list(self._active_searches):
            if hasattr(worker, "cancel"):
                worker.cancel.set()
            if thread.isRunning():
                thread.quit()
        self._search_gen += 1
        gen = self._search_gen
        if best:
            self.context = "best"
        else:
            self.context = "search" if query else "categories"
        if category is not None:
            self.current_category = category
        self.current_query = query
        self.results.set_context(self.context)
        self.search_bar.set_searching(True)
        self.search_bar.reset_progress()
        self._elapsed.start()
        self._elapsed_timer.start()
        self.search_bar.set_status(self.tr.t("searching"))

        params = dict(
            query=query or "wallpaper",
            limit=limit or int(self.settings.get("page_size", 80)),
            sort=self.search_bar.sort_key(),
            category=self.current_category,
            time_range=self.search_bar.time_range(),
        )
        if best:
            params["sort"] = SortKey.POPULARITY
            params["time_range"] = self.search_bar.time_range()
        self._last_search = (query, best, self.current_category, params["limit"])
        thread = QThread(self)
        cancel_event = Event()
        worker = SearchWorker(self.manager, params, gen, cancel_event)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        # Sygnały łączymy z metodami MainWindow (QObject w głównym wątku)
        # i jawnie przez kolejkę Qt. Lambda nie ma odbiorcy QObject i mogłaby
        # wykonać się w wątku roboczym, co psuje GUI (a nawet crashuje Qt).
        worker.progress.connect(self._progress_from_worker, Qt.ConnectionType.QueuedConnection)
        worker.finished.connect(self._finished_from_worker, Qt.ConnectionType.QueuedConnection)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._on_thread_finished, Qt.ConnectionType.QueuedConnection)
        self._active_searches.append((thread, worker, gen))
        self._thread = thread
        self._worker = worker
        thread.start()

    def _forget_search(self, thread: QThread) -> None:
        self._active_searches = [item for item in self._active_searches if item[0] is not thread]

    def _progress_from_worker(self, name: str, count: int, ok: bool, gen: int) -> None:
        self._on_search_progress(name, count, ok, gen)

    def _finished_from_worker(self, result, gen: int) -> None:
        self._on_search_finished(result, gen)

    def _on_thread_finished(self) -> None:
        self._forget_search(self.sender())

    def _refresh_search(self) -> None:
        last = getattr(self, "_last_search", None)
        if not last:
            self.search_bar.set_status(self.tr.t("no_results"))
            return
        query, best, category, limit = last
        self.start_search(query, best=best, category=category, limit=limit)

    def _load_more(self) -> None:
        last = getattr(self, "_last_search", None)
        if not last:
            self.search_bar.set_status(self.tr.t("no_results"))
            return
        query, best, category, old_limit = last
        self.start_search(query, best=best, category=category, limit=old_limit + 80)

    def _tick_elapsed(self) -> None:
        self.search_bar.set_elapsed(self._elapsed.elapsed() / 1000.0)

    def _on_search_progress(self, name: str, count: int, ok: bool, gen: int | None = None) -> None:
        if gen is not None and gen != self._search_gen:
            return  # wynik ze starego zapytania - ignoruj
        self.search_bar.set_source_progress(name, count, ok)
        self.search_bar.set_elapsed(self._elapsed.elapsed() / 1000.0)

    def _on_search_finished(self, result, gen: int | None = None) -> None:
        if gen is not None and gen != self._search_gen:
            return  # stary wątek skończył się po nowym zapytaniu
        self.search_bar.set_searching(False)
        self._elapsed_timer.stop()
        self.search_bar.set_elapsed(result.elapsed if result is not None else self._elapsed.elapsed() / 1000.0)
        if result is None:
            self.search_bar.set_status("❌ " + getattr(self._worker, "error_text", "Błąd wyszukiwania"))
            return
        items = list(result.items)
        # Doprecyzowanie: następne zapytanie DOKŁADA wyniki do poprzednich
        # zamiast je wyrzucać. Pełna fraza decyduje o kolejności.
        previous = list(self.current_results)
        can_accumulate = (
            self.search_bar.accumulate_btn.isChecked()
            and previous
            and self.context in ("search", "categories", "best")
        )
        if can_accumulate:
            combined = {w.id: w for w in previous}
            for w in items:
                combined[w.id] = w
            items = list(combined.values())
            prepared = prepare_query(self.current_query, self.current_category)
            if prepared["user_words"]:
                items.sort(key=lambda w: relevance_score(w, prepared), reverse=True)
            limit = getattr(self, "_last_search", (None, None, None, 80))[3]
            items = items[:limit]

        self.current_results = items
        self.results.set_wallpapers(self.current_results)
        self.results.set_context(self.context)
        self.search_bar.set_counts(result.count, result.sources_ok)
        if result.count == 0 and self.settings.get("language") == "pl":
            self.results.set_theme_hint(self.tr.t("no_results"))

    # --- akcje nawigacji ---------------------------------------------------
    def _on_nav(self, key: str) -> None:
        if key == "home":
            self.context = "home"
            self.current_results = []
            self.results.set_wallpapers([])
            self.results.set_context("home")
            self.search_bar.set_status(self.tr.t("welcome_title"))
            self.detail.hide()
        elif key == "favorites":
            self.context = "favorites"
            items = list(self._favorites.values())
            self.current_results = items
            self.results.set_wallpapers(items)
            self.results.set_context("favorites")
            self.search_bar.set_status(self.tr.t("favorites") + f": {len(items)}")
        elif key == "categories":
            self.context = "categories"
            self.results.set_wallpapers(list(self.current_results))
            self.results.set_context("categories")
            self.search_bar.set_status(self.tr.t("categories") + " — " + self.tr.t("welcome_text"))
        elif key == "best":
            self.start_search("", best=True)
        elif key == "recent":
            self.context = "recent"
            items = list(self._history.values())
            self.current_results = items
            self.results.set_wallpapers(items)
            self.results.set_context("recent")
            self.search_bar.set_status(self.tr.t("recent") + f": {len(items)}")
        elif key == "collections":
            self.open_collections()
            self.sidebar.select_nav(self.context if self.context in
                                    ("home", "favorites", "best", "recent", "categories", "collections") else "home")
        elif key == "settings":
            self.open_settings()
        elif key == "about":
            AboutDialog(self.tr, self).exec()

    def _on_category(self, cid: str) -> None:
        self.current_category = cid
        if self.context == "favorites":
            items = [w for w in self._favorites.values() if cid == "all" or w.category == cid]
            self.current_results = items
            self.results.set_wallpapers(items)
            return
        self.start_search(self.current_query or "wallpaper", category=cid)

    def _on_fav_filter(self, active: bool) -> None:
        if active:
            items = [w for w in self.current_results if w.id in self._favorites]
        else:
            items = self.current_results
        self.results.set_wallpapers(items)

    # --- filtry lokalne ----------------------------------------------------
    def _on_sort_changed(self, key: SortKey) -> None:
        if not self.current_results:
            return
        self.current_results = sort_wallpapers(self.current_results, key)
        self.results.set_wallpapers(self.current_results)

    def _on_time_changed(self, rng: TimeRange) -> None:
        if not self.current_results:
            return
        self.current_results = filter_by_time(self.current_results, rng)
        self.results.set_wallpapers(self.current_results)

    def _on_view_changed(self, mode: ViewMode) -> None:
        self.results.set_mode(mode)
        self.settings.set("view_mode", mode.value)
        self.settings.save()

    # --- ulubione / podgląd / pobieranie ----------------------------------
    def toggle_favorite(self, wallpaper: Wallpaper) -> None:
        if wallpaper.id in self._favorites:
            self._favorites.pop(wallpaper.id, None)
            self.settings.remove_favorite(wallpaper.id)
            fav = False
        else:
            self._favorites[wallpaper.id] = wallpaper
            self.settings.add_favorite(wallpaper)
            fav = True
        self._sync_favorite_set()
        self.results.set_favorite_state(wallpaper.id, fav)
        self.detail.set_favorite(fav)
        self.slideshow.set_favorite(fav)

    def preview_wallpaper(self, wallpaper: Wallpaper) -> None:
        self.settings.add_history(wallpaper)
        self._history[wallpaper.id] = wallpaper
        self.detail.show()
        self.detail.set_wallpaper(wallpaper, wallpaper.id in self._favorites)
        index = next((i for i, w in enumerate(self.current_results) if w.id == wallpaper.id), 0)
        self.slideshow.set_items(self.current_results or [wallpaper], index)
        self.slideshow.set_favorite(wallpaper.id in self._favorites)
        self.slideshow.show()

    def open_slideshow(self, index: int = 0) -> None:
        if not self.current_results:
            self.search_bar.set_status(self.tr.t("no_results"))
            return
        self.slideshow.set_items(self.current_results, index)
        if self.current_results:
            self.slideshow.set_favorite(self.current_results[index].id in self._favorites)
        self.slideshow.show()

    def open_slideshow_at_detail(self) -> None:
        wallpaper = self.detail.wallpaper
        if wallpaper is None:
            self.open_slideshow()
            return
        index = next((i for i, w in enumerate(self.current_results) if w.id == wallpaper.id), 0)
        self.open_slideshow(index)

    def download_wallpaper(self, wallpaper: Wallpaper) -> None:
        folder = self.settings.get("download_dir", "") or str(Path.home() / "Pictures" / "OmniFoto")
        ext = (wallpaper.format or "jpg").lower().lstrip(".")
        name = safe_filename(wallpaper.title or "wallpaper") + "." + ext
        path_str, _ = QFileDialog.getSaveFileName(
            self, self.tr.t("download"), str(Path(folder) / name),
            "Obrazy (*.jpg *.png *.webp *.avif *.svg);;Wszystkie pliki (*)",
        )
        if not path_str:
            return
        path = Path(path_str)
        self._thread = QThread(self)
        self._worker = DownloadWorker(self.session, wallpaper.url, path)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.finished.connect(
            self._on_download_finished, Qt.ConnectionType.QueuedConnection
        )
        self._worker.finished.connect(self._thread.quit)
        self._worker.finished.connect(self._worker.deleteLater)
        self._thread.finished.connect(self._thread.deleteLater)
        self._thread.start()

    def _on_download_finished(self, ok: bool, message: str) -> None:
        if ok:
            self.search_bar.set_status("✅ " + self.tr.t("download_done", name=Path(message).name))
        else:
            QMessageBox.warning(self, self.tr.t("download"), message)

    # --- kolekcje i skórki -------------------------------------------------
    def open_collections(self) -> None:
        dlg = CollectionsDialog(self.tr, self.settings, self)
        dlg.show_requested.connect(self.show_collection)
        dlg.collections_changed.connect(self.sidebar.refresh_collections)
        dlg.exec()

    def open_collection_by_name(self, name: str) -> None:
        for col in self.settings.collections():
            if col.get("name") == name:
                self.show_collection(col.get("items", []), name)
                self.sidebar.select_nav("collections")
                return

    def show_collection(self, items, name: str) -> None:
        self.context = "collections"
        converted = []
        for item in items:
            if isinstance(item, Wallpaper):
                converted.append(item)
            else:
                try:
                    converted.append(Wallpaper.from_dict(item))
                except Exception:
                    continue
        self.current_results = converted
        self.results.set_wallpapers(self.current_results)
        self.results.set_context("collections")
        self.search_bar.set_status(f"📚 {name}: {len(items)}")

    def add_to_collection(self, wallpaper: Wallpaper) -> None:
        cid = choose_collection(self.tr, self.settings, self)
        if cid:
            self.settings.add_to_collection(cid, wallpaper)
            self.search_bar.set_status("✅ " + wallpaper.title[:40])

    def cycle_theme(self) -> None:
        current = self.settings.get("theme", "azureus")
        order = list(THEME_CYCLE_ORDER)
        nxt = order[(order.index(current) + 1) % len(order)] if current in order else order[0]
        self.settings.set("theme", nxt)
        self.settings.save()
        self._apply_all_theme()
        self.results.set_colors(self.colors)
        items = list(self.current_results)
        self.results.set_wallpapers([])
        self.results.set_wallpapers(items)
        self.detail.set_colors(self.colors)
        if self.detail.wallpaper is not None:
            self.detail.set_wallpaper(self.detail.wallpaper, self.detail.wallpaper.id in self._favorites)
        self.search_bar.set_status("🎨 " + self.settings.get("theme", ""))

    # --- ustawienia, motyw, język -----------------------------------------
    def open_settings(self) -> None:
        dlg = SettingsDialog(self.tr, self.settings, self)
        dlg.settings_changed.connect(self._on_settings_changed)
        dlg.exec()

    def _on_settings_changed(self) -> None:
        self.settings.save()
        self.tr.set_language(self.settings.get("language", "pl"))
        # nowe ustawienia proxy / User-Agent -> nowa sesja HTTP
        self.session = PrivacySession(self.settings, timeout=6)
        self.manager = SearchManager(self.session, self.settings)
        self._apply_all_theme()
        self.sidebar.retranslate_all()
        self.search_bar.retranslate()
        self.loader.set_user_agent(self.session.user_agent)
        # odśwież kafelki, aby przyjęły nowy motyw
        self.results.set_colors(self.colors)
        items = list(self.current_results)
        self.results.set_wallpapers([])
        self.results.set_wallpapers(items)
        if self.detail.wallpaper is not None:
            self.detail.set_wallpaper(self.detail.wallpaper, self.detail.wallpaper.id in self._favorites)

    def _apply_all_theme(self) -> None:
        key = self.settings.get("theme", "azureus")
        apply_theme(self.app, key)
        self.colors = theme_colors(key)
        self.search_bar.set_progress_colors(self.colors)

    # --- responsywność -----------------------------------------------------
    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        narrow = self.width() < 1080
        if narrow and self.detail.isVisible():
            self._detail_was_visible = True
            self.detail.hide()
        elif not narrow and self._detail_was_visible and not self.detail.isVisible():
            self.detail.show()
            self._detail_was_visible = False

    # --- zamykanie ---------------------------------------------------------
    def closeEvent(self, event: QCloseEvent) -> None:  # noqa: N802
        for thread, worker, _gen in list(self._active_searches):
            if hasattr(worker, "cancel"):
                worker.cancel.set()
            if thread.isRunning():
                thread.quit()
                thread.wait(1500)
        self._active_searches.clear()
        if not self.settings.privacy_mode:
            self.settings.save()
        super().closeEvent(event)
