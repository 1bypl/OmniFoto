"""Asynchroniczne ładowanie miniaturek z pamięci podręcznej (bez zapisu na dysk).

Używa QNetworkAccessManager z Qt, więc obsługuje JPEG/PNG/WebP/GIF oraz - przez
QSvgRenderer - grafikę SVG. Dane „data:...” (używane przez tryb demo) są
dekodowane lokalnie.
"""

from __future__ import annotations

import base64
from collections import OrderedDict
from pathlib import Path
from typing import Any

from PySide6.QtCore import QByteArray, QObject, QSize, Qt, Signal
from PySide6.QtGui import QImage, QImageReader, QPainter, QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest
from PySide6.QtSvg import QSvgRenderer

from ..privacy import USER_AGENTS

MAX_CACHE = 160


def pixmap_from_bytes(data: QByteArray | bytes, target: QSize | None = None, svg: bool = False) -> QPixmap:
    """Tworzy QPixmap z bajtów, opcjonalnie skalując i renderując SVG."""
    pix = QPixmap()
    if svg:
        renderer = QSvgRenderer(QByteArray(bytes(data)))
        if not renderer.isValid():
            return pix
        size = target or QSize(renderer.defaultSize())
        if size.isEmpty():
            size = QSize(640, 360)
        image = QImage(size, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        painter = QPainter(image)
        renderer.render(painter)
        painter.end()
        pix = QPixmap.fromImage(image)
    else:
        if not pix.loadFromData(QByteArray(bytes(data))):
            return pix
    if target is not None and not target.isEmpty() and not pix.isNull():
        pix = pix.scaled(target, Qt.AspectRatioMode.KeepAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
    return pix


def pixmap_from_file(path: Path, target: QSize | None = None) -> QPixmap:
    """Dekoduje lokalny obraz od razu do żądanego rozmiaru - znacznie szybciej
    niż wczytanie całego pliku i dopiero potem skalowanie."""
    if path.suffix.lower() == ".svg":
        return pixmap_from_bytes(path.read_bytes(), target, svg=True)
    reader = QImageReader(str(path))
    if target is not None and not target.isEmpty():
        reader.setScaledSize(target)
    image = reader.read()
    if image.isNull():
        return QPixmap()
    return QPixmap.fromImage(image)


class ImageLoader(QObject):
    pixmap_ready = Signal(str, QPixmap)
    load_failed = Signal(str)

    def __init__(self, parent: QObject | None = None, max_cache: int = MAX_CACHE) -> None:
        super().__init__(parent)
        self._manager = QNetworkAccessManager(self)
        self._manager.finished.connect(self._on_finished)
        self._cache: OrderedDict[str, QPixmap] = OrderedDict()
        self._max_cache = max_cache
        self._urls: dict[QNetworkReply, str] = {}
        self._user_agent = USER_AGENTS[0]

    def set_user_agent(self, ua: str) -> None:
        if ua:
            self._user_agent = ua

    @staticmethod
    def key(url: str, size: QSize | None) -> str:
        if size is None:
            return f"{url}|full"
        return f"{url}|{size.width()}x{size.height()}"

    def load(self, url: str, target: QSize | None = None) -> QPixmap | None:
        """Zwraca pixmapę z cache albo rozpoczyna pobieranie (zwraca None)."""
        if not url:
            self.load_failed.emit("")
            return None
        key = self.key(url, target)
        if key in self._cache:
            self._cache.move_to_end(key)
            pix = self._cache[key]
            self.pixmap_ready.emit(key, pix)
            return pix

        if url.startswith("data:"):
            pix = self._decode_data_uri(url, target)
            if not pix.isNull():
                self._cache[key] = pix
                self.pixmap_ready.emit(key, pix)
            else:
                self.load_failed.emit(url)
            return pix if not pix.isNull() else None

        # lokalny plik graficzny (własne kolekcje) - czytaj bezpośrednio
        if not url.startswith(("http://", "https://", "file:")):
            local = Path(url)
            if local.is_file():
                try:
                    pix = pixmap_from_file(local, target)
                except OSError:
                    pix = QPixmap()
                if not pix.isNull():
                    self._cache[key] = pix
                    if len(self._cache) > self._max_cache:
                        self._cache.popitem(last=False)
                    self.pixmap_ready.emit(key, pix)
                    return pix
            self.load_failed.emit(url)
            return None

        request = QNetworkRequest(url)
        request.setRawHeader(b"User-Agent", self._user_agent.encode("utf-8", "ignore"))
        request.setRawHeader(b"DNT", b"1")
        try:
            request.setAttribute(
                QNetworkRequest.Attribute.CacheLoadControlAttribute,
                QNetworkRequest.CacheLoadControl.AlwaysNetwork,
            )
        except AttributeError:
            pass  # starsza wersja PySide6 - domyślne zachowanie jest OK
        reply = self._manager.get(request)
        self._urls[reply] = key
        reply.finished.connect(lambda r=reply: self._urls.pop(r, None))
        return None

    def _decode_data_uri(self, url: str, target: QSize | None) -> QPixmap:
        try:
            header, payload = url.split(",", 1)
            svg = "svg+xml" in header
            data = base64.b64decode(payload) if ";base64" in header else payload.encode("utf-8")
            return pixmap_from_bytes(data, target, svg=svg)
        except Exception:
            return QPixmap()

    def _on_finished(self, reply: QNetworkReply) -> None:
        key = self._urls.pop(reply, None)
        if key is None:
            reply.deleteLater()
            return
        try:
            if reply.error() == QNetworkReply.NetworkError.NoError:
                data = bytes(reply.readAll())
                ctype = reply.header(QNetworkRequest.KnownHeaders.ContentTypeHeader)
                svg = "svg" in str(ctype or "").lower()
                pix = pixmap_from_bytes(data, self._target_from_key(key), svg=svg)
                if not pix.isNull():
                    self._cache[key] = pix
                    if len(self._cache) > self._max_cache:
                        self._cache.popitem(last=False)
                    self.pixmap_ready.emit(key, pix)
                else:
                    self.load_failed.emit(key)
            else:
                self.load_failed.emit(key)
        finally:
            reply.deleteLater()

    @staticmethod
    def _target_from_key(key: str) -> QSize | None:
        if key.endswith("|full"):
            return None
        dims = key.rsplit("|", 1)[-1]
        try:
            w, h = dims.split("x")
            return QSize(int(w), int(h))
        except Exception:
            return None

    def clear(self) -> None:
        self._cache.clear()
