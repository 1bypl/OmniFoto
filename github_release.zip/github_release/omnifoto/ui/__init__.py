"""Interfejs użytkownika OmniFoto (PySide6 / Qt)."""
