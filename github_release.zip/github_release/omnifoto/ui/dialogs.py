"""Okna dialogowe: Ustawienia, Edycja źródła/kategorii, O programie."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QSpinBox, QTabWidget, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from .. import __version__, GITHUB, LICENSE
from ..constants import LANGUAGES, THEMES
from .sidebar import ASSETS, svg_pixmap


class SourceEditDialog(QDialog):
    def __init__(self, translator, data: dict | None = None, parent=None) -> None:
        super().__init__(parent)
        self.tr = translator
        self.setWindowTitle(self.tr.t("edit") if data else self.tr.t("add"))
        form = QFormLayout(self)
        self.name = QLineEdit((data or {}).get("name", ""))
        self.url = QLineEdit((data or {}).get("url", ""))
        self.kind = QComboBox()
        self.kind.addItems(["api", "scrape", "demo"])
        self.kind.setCurrentText((data or {}).get("kind", "api"))
        self.note = QLineEdit((data or {}).get("note", ""))
        self.enabled = QCheckBox(self.tr.t("enabled"))
        self.enabled.setChecked((data or {}).get("enabled", True))
        form.addRow(self.tr.t("name"), self.name)
        form.addRow(self.tr.t("url"), self.url)
        form.addRow("Typ", self.kind)
        form.addRow("Opis", self.note)
        form.addRow(self.enabled)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def values(self) -> dict:
        return {
            "id": self.name.text().strip().lower().replace(" ", "_"),
            "name": self.name.text().strip() or "Źródło",
            "url": self.url.text().strip(),
            "kind": self.kind.currentText(),
            "note": self.note.text().strip(),
            "enabled": self.enabled.isChecked(),
            "key": False,
        }


class CategoryEditDialog(QDialog):
    def __init__(self, translator, data: dict | None = None, parent=None) -> None:
        super().__init__(parent)
        self.tr = translator
        self.setWindowTitle(self.tr.t("edit") if data else self.tr.t("add"))
        form = QFormLayout(self)
        self.name = QLineEdit((data or {}).get("name", ""))
        self.icon = QLineEdit((data or {}).get("icon", "⭐"))
        self.id_edit = QLineEdit((data or {}).get("id", ""))
        if data:
            self.id_edit.setReadOnly(True)
        form.addRow(self.tr.t("name"), self.name)
        form.addRow(self.tr.t("icon"), self.icon)
        form.addRow("ID", self.id_edit)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def values(self) -> dict:
        cid = self.id_edit.text().strip() or self.name.text().strip().lower().replace(" ", "_")
        return {"id": cid, "name": self.name.text().strip() or cid, "icon": self.icon.text().strip() or "⭐"}


class SettingsDialog(QDialog):
    settings_changed = Signal()

    def __init__(self, translator, settings, parent=None) -> None:
        super().__init__(parent)
        self.tr = translator
        self.settings = settings
        self.setWindowTitle(self.tr.t("settings"))
        self.resize(760, 560)

        root = QVBoxLayout(self)
        self.tabs = QTabWidget()
        root.addWidget(self.tabs)
        self._build_general()
        self._build_sources()
        self._build_categories()
        self._build_keys()

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    # --- zakładka: ogólne --------------------------------------------------
    def _build_general(self) -> None:
        page = QWidget()
        form = QFormLayout(page)
        self.lang = QComboBox()
        for code, name in LANGUAGES.items():
            self.lang.addItem(name, code)
        self.lang.setCurrentText(LANGUAGES.get(self.settings.get("language", "pl"), "Polski"))
        form.addRow(self.tr.t("language"), self.lang)

        self.theme = QComboBox()
        for key, data in THEMES.items():
            self.theme.addItem(data["name"], key)
        self.theme.setCurrentText(THEMES.get(self.settings.get("theme", "azureus"), THEMES["azureus"])["name"])
        form.addRow(self.tr.t("theme"), self.theme)

        self.view_mode = QComboBox()
        self.view_mode.addItem(self.tr.t("tiles"), "tiles")
        self.view_mode.addItem(self.tr.t("list"), "list")
        self.view_mode.setCurrentText(self.tr.t("tiles") if self.settings.get("view_mode") == "tiles" else self.tr.t("list"))
        form.addRow("Widok domyślny", self.view_mode)

        self.page_size = QSpinBox()
        self.page_size.setRange(10, 200)
        self.page_size.setValue(int(self.settings.get("page_size", 40)))
        form.addRow("Wyników na stronę", self.page_size)

        self.privacy = QCheckBox(self.tr.t("privacy_mode"))
        self.privacy.setChecked(self.settings.privacy_mode)
        form.addRow("Prywatność", self.privacy)

        dl = QHBoxLayout()
        self.download_dir = QLineEdit(self.settings.get("download_dir", ""))
        choose = QPushButton(self.tr.t("choose"))
        choose.clicked.connect(self._choose_dir)
        dl.addWidget(self.download_dir)
        dl.addWidget(choose)
        form.addRow(self.tr.t("download_dir"), dl)

        proxy_box = QGroupBox(self.tr.t("proxy"))
        pf = QFormLayout(proxy_box)
        self.proxy_enabled = QCheckBox(self.tr.t("proxy_enabled"))
        self.proxy_enabled.setChecked(self.settings.get("proxy_enabled", False))
        pf.addRow(self.proxy_enabled)
        self.proxy_host = QLineEdit(self.settings.get("proxy_host", "127.0.0.1"))
        self.proxy_port = QSpinBox()
        self.proxy_port.setRange(1, 65535)
        self.proxy_port.setValue(int(self.settings.get("proxy_port", 9050)))
        self.proxy_type = QComboBox()
        self.proxy_type.addItems(["socks5", "http", "https"])
        self.proxy_type.setCurrentText(self.settings.get("proxy_type", "socks5"))
        pf.addRow(self.tr.t("proxy_host"), self.proxy_host)
        pf.addRow(self.tr.t("proxy_port"), self.proxy_port)
        pf.addRow(self.tr.t("proxy_type"), self.proxy_type)
        note = QLabel("Wskazówka: Tor SOCKS5 zwykle działa na 127.0.0.1:9050.\nWymagany jest PySocks (opcjonalny moduł).")
        note.setWordWrap(True)
        note.setObjectName("hint")
        pf.addRow(note)
        form.addRow(proxy_box)
        self.tabs.addTab(page, self.tr.t("settings"))

    # --- zakładka: źródła --------------------------------------------------
    def _build_sources(self) -> None:
        page = QWidget()
        lay = QVBoxLayout(page)
        self.sources_table = QTableWidget(0, 4)
        self.sources_table.setHorizontalHeaderLabels(["✓", self.tr.t("name"), "Typ", self.tr.t("url")])
        self.sources_table.horizontalHeader().setStretchLastSection(True)
        self.sources_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.sources_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        lay.addWidget(self.sources_table)
        self._fill_sources()

        row = QHBoxLayout()
        add = QPushButton("＋ " + self.tr.t("add"))
        edit = QPushButton("✎ " + self.tr.t("edit"))
        remove = QPushButton("－ " + self.tr.t("remove"))
        add.clicked.connect(self._add_source)
        edit.clicked.connect(self._edit_source)
        remove.clicked.connect(self._remove_source)
        row.addWidget(add)
        row.addWidget(edit)
        row.addWidget(remove)
        lay.addLayout(row)
        self.tabs.addTab(page, self.tr.t("sources_settings"))

    def _fill_sources(self) -> None:
        self.sources_table.setRowCount(0)
        for src in self.settings.get("sources", []):
            r = self.sources_table.rowCount()
            self.sources_table.insertRow(r)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            chk.setCheckState(Qt.CheckState.Checked if src.get("enabled", True) else Qt.CheckState.Unchecked)
            self.sources_table.setItem(r, 0, chk)
            self.sources_table.setItem(r, 1, QTableWidgetItem(src.get("name", "")))
            self.sources_table.setItem(r, 2, QTableWidgetItem(src.get("kind", "")))
            self.sources_table.setItem(r, 3, QTableWidgetItem(src.get("url", "")))
            self.sources_table.item(r, 0).setData(Qt.ItemDataRole.UserRole, src)

    def _source_at(self, row: int) -> dict | None:
        item = self.sources_table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _add_source(self) -> None:
        dlg = SourceEditDialog(self.tr, parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            sources = list(self.settings.get("sources", []))
            sources.append(dlg.values())
            self.settings.set("sources", sources)
            self._fill_sources()

    def _edit_source(self) -> None:
        row = self.sources_table.currentRow()
        src = self._source_at(row)
        if not src:
            return
        dlg = SourceEditDialog(self.tr, src, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            sources = list(self.settings.get("sources", []))
            for i, s in enumerate(sources):
                if s.get("id") == src.get("id"):
                    sources[i] = dlg.values()
                    break
            self.settings.set("sources", sources)
            self._fill_sources()

    def _remove_source(self) -> None:
        row = self.sources_table.currentRow()
        src = self._source_at(row)
        if not src:
            return
        if QMessageBox.question(self, self.tr.t("confirm_remove"), src.get("name", "")) == QMessageBox.StandardButton.Yes:
            sources = [s for s in self.settings.get("sources", []) if s.get("id") != src.get("id")]
            self.settings.set("sources", sources)
            self._fill_sources()

    # --- zakładka: kategorie -----------------------------------------------
    def _build_categories(self) -> None:
        page = QWidget()
        lay = QVBoxLayout(page)
        self.cat_list = QListWidget()
        for cat in self.settings.get("categories", []):
            item = QListWidgetItem(f"{cat.get('icon','')}  {cat.get('name','')}")
            item.setData(Qt.ItemDataRole.UserRole, cat)
            self.cat_list.addItem(item)
        lay.addWidget(self.cat_list)
        row = QHBoxLayout()
        add = QPushButton("＋ " + self.tr.t("add"))
        edit = QPushButton("✎ " + self.tr.t("edit"))
        remove = QPushButton("－ " + self.tr.t("remove"))
        add.clicked.connect(self._add_category)
        edit.clicked.connect(self._edit_category)
        remove.clicked.connect(self._remove_category)
        row.addWidget(add)
        row.addWidget(edit)
        row.addWidget(remove)
        lay.addLayout(row)
        self.tabs.addTab(page, self.tr.t("categories_settings"))

    def _add_category(self) -> None:
        dlg = CategoryEditDialog(self.tr, parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            cats = list(self.settings.get("categories", []))
            cats.append(dlg.values())
            self.settings.set("categories", cats)
            self.cat_list.addItem(QListWidgetItem(f"{dlg.values()['icon']}  {dlg.values()['name']}"))
            self.cat_list.item(self.cat_list.count() - 1).setData(Qt.ItemDataRole.UserRole, dlg.values())

    def _edit_category(self) -> None:
        item = self.cat_list.currentItem()
        if not item:
            return
        cat = item.data(Qt.ItemDataRole.UserRole)
        dlg = CategoryEditDialog(self.tr, cat, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            val = dlg.values()
            cats = [val if c.get("id") == cat.get("id") else c for c in self.settings.get("categories", [])]
            self.settings.set("categories", cats)
            item.setText(f"{val['icon']}  {val['name']}")
            item.setData(Qt.ItemDataRole.UserRole, val)

    def _remove_category(self) -> None:
        item = self.cat_list.currentItem()
        if not item:
            return
        cat = item.data(Qt.ItemDataRole.UserRole)
        if QMessageBox.question(self, self.tr.t("confirm_remove"), cat.get("name", "")) == QMessageBox.StandardButton.Yes:
            cats = [c for c in self.settings.get("categories", []) if c.get("id") != cat.get("id")]
            self.settings.set("categories", cats)
            self.cat_list.takeItem(self.cat_list.row(item))

    # --- zakładka: klucze API ----------------------------------------------
    def _build_keys(self) -> None:
        page = QWidget()
        form = QFormLayout(page)
        keys = self.settings.api_keys
        self.key_edits: dict[str, QLineEdit] = {}
        for svc, hint_url in (
            ("unsplash", "https://unsplash.com/developers"),
            ("pexels", "https://www.pexels.com/api/"),
            ("pixabay", "https://pixabay.com/api/docs/"),
        ):
            edit = QLineEdit(keys.get(svc, ""))
            edit.setEchoMode(QLineEdit.EchoMode.Password)
            self.key_edits[svc] = edit
            form.addRow(svc, edit)
            link = QLabel(f'<a href="{hint_url}">{hint_url}</a>')
            link.setOpenExternalLinks(True)
            link.setObjectName("hint")
            form.addRow("", link)
        note = QLabel("Klucze są przechowywane lokalnie w pliku settings.json.\nMożesz je usunąć w każdej chwili.")
        note.setObjectName("hint")
        note.setWordWrap(True)
        form.addRow(note)
        self.tabs.addTab(page, self.tr.t("api_keys"))

    # --- zapis -------------------------------------------------------------
    def _choose_dir(self) -> None:
        path = QFileDialog.getExistingDirectory(self, self.tr.t("download_dir"), self.download_dir.text())
        if path:
            self.download_dir.setText(path)

    def _save(self) -> None:
        # odczytaj checkboxy źródeł sprzed zapisu
        sources = list(self.settings.get("sources", []))
        for r in range(self.sources_table.rowCount()):
            src = self._source_at(r)
            if not src:
                continue
            chk = self.sources_table.item(r, 0)
            for s in sources:
                if s.get("id") == src.get("id"):
                    s["enabled"] = chk.checkState() == Qt.CheckState.Checked
                    break
        self.settings.update(
            language=self.lang.currentData(),
            theme=self.theme.currentData(),
            view_mode=self.view_mode.currentData(),
            page_size=self.page_size.value(),
            privacy_mode=self.privacy.isChecked(),
            download_dir=self.download_dir.text().strip(),
            proxy_enabled=self.proxy_enabled.isChecked(),
            proxy_host=self.proxy_host.text().strip(),
            proxy_port=self.proxy_port.value(),
            proxy_type=self.proxy_type.currentText(),
            sources=sources,
        )
        api = dict(self.settings.api_keys)
        for svc, edit in self.key_edits.items():
            api[svc] = edit.text().strip()
        self.settings.set("api_keys", api)
        self.settings.save()
        self.settings_changed.emit()
        self.accept()


class AboutDialog(QDialog):
    def __init__(self, translator, parent=None) -> None:
        super().__init__(parent)
        self.tr = translator
        self.setWindowTitle(self.tr.t("about"))
        self.setFixedSize(480, 420)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        frog = QLabel()
        frog.setObjectName("mascotLabel")
        frog.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        frog.setPixmap(svg_pixmap(ASSETS / "mascot.svg", QPixmap(120, 120).size()))
        frog.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(frog)

        title = QLabel("OmniFoto 🐸")
        title.setObjectName("logoTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)

        info = QLabel(
            f"{self.tr.t('version')}: {__version__}\n"
            f"{self.tr.t('author_label')}: 1bypl\n"
            f"{self.tr.t('license')}: GPL-3.0-or-later\n"
            "Fedora • Debian • Ubuntu • Windows (planowane)"
        )
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setObjectName("cardMeta")
        lay.addWidget(info)

        text = QLabel(self.tr.t("about_text"))
        text.setWordWrap(True)
        text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(text)

        self.privacy_label = QLabel("🔒 " + self.tr.t("privacy_hint"))
        self.privacy_label.setWordWrap(True)
        self.privacy_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.privacy_label.setObjectName("hint")
        lay.addWidget(self.privacy_label)

        gh = QPushButton(f"🐙 {self.tr.t('github')}: 1bypl")
        gh.setObjectName("previewButton")
        gh.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(GITHUB)))
        lay.addWidget(gh)

        lic = QPushButton(self.tr.t("license") + " GPL-3.0")
        lic.setObjectName("previewButton")
        lic.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://www.gnu.org/licenses/gpl-3.0.html")))
        lay.addWidget(lic)

        close = QPushButton(self.tr.t("close"))
        close.clicked.connect(self.accept)
        lay.addWidget(close)
