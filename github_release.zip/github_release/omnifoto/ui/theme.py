"""Motywy wyglądu (QSS) generowane z palet zdefiniowanych w constants.py."""

from __future__ import annotations

from string import Template

from PySide6.QtWidgets import QApplication

from ..constants import THEMES

QSS_TEMPLATE = Template(r"""
* { font-family: "Segoe UI", "Noto Sans", "Inter", sans-serif; }
QWidget { background: $bg; color: $text; font-size: 13px; }
QMainWindow, QDialog { background: $bg; }

/* --- Pasek boczny ------------------------------------------------------- */
#sidebar { background: $bg2; border-right: 1px solid $border; }
#logoBox { background: transparent; }
#mascotLabel { background: transparent; border: none; }
#logoTitle { font-size: 21px; font-weight: 700; color: $accent2;
             background: transparent; border: none; }
#logoSub { font-size: 10px; color: $muted; background: transparent; border: none; }
#navTitle { font-size: 10px; font-weight: 700; color: $muted; letter-spacing: 1px; }

QPushButton { background: $panel; color: $text; border: 1px solid $border;
              border-radius: 9px; padding: 9px 13px; }
QPushButton:hover { background: $card; border-color: $accent; }
QPushButton:pressed { background: $accent; color: #ffffff; }
QPushButton:checked { background: $accent; color: #ffffff; border-color: $accent; }
QPushButton:disabled { opacity: .5; }

#navButton { background: transparent; border: 1px solid transparent; text-align: left;
             padding: 11px 14px; font-size: 14px; border-radius: 10px; }
#navButton:hover { background: $card; border-color: $border; }
#navButton:checked { background: $accent; color: #ffffff; border-color: $accent; }

/* --- Nagłówek / wyszukiwarka -------------------------------------------- */
#header { background: $bg2; border-bottom: 1px solid $border; }
#searchInput { background: $panel; border: 2px solid $border; border-radius: 9px;
               padding: 5px 11px; font-size: 13px; selection-background-color: $accent; }
#searchInput:focus { border-color: $accent; }
#searchButton { background: $accent; color: #ffffff; font-weight: 700;
                border: 1px solid $accent; border-radius: 9px; padding: 5px 14px; }
#searchButton:hover { background: $accent2; color: $bg; }
#chip { background: $panel; border: 1px solid $border; border-radius: 7px; padding: 4px 8px; }
#chip:checked { background: $accent; color: #ffffff; border-color: $accent; }
#counter { color: $muted; font-size: 12px; }
#hint { color: $muted; font-size: 11px; }
#themeButton { background: $accent2; color: $bg; font-weight: 700; border: 1px solid $accent; }
#themeButton:hover { background: $gold; color: $bg; border-color: $gold; }

/* --- Kafelki ------------------------------------------------------------ */
#card { background: $card; border: 1px solid $border; border-radius: 14px; }
#card:hover { border-color: $accent; }
#cardTitle { font-weight: 700; font-size: 13px; }
#cardMeta { color: $muted; font-size: 11px; }
#tag { background: $panel; color: $accent2; border: 1px solid $border;
       border-radius: 6px; padding: 2px 6px; font-size: 10px; }
#starButton { background: transparent; border: none; font-size: 20px; padding: 2px 5px; }
#downloadButton { background: $good; color: #ffffff; font-weight: 700; border-radius: 8px;
                  padding: 6px 12px; border: none; }
#downloadButton:hover { opacity: .85; }
#previewButton { background: transparent; border: 1px solid $border; border-radius: 8px;
                 padding: 6px 10px; }
#previewButton:hover { border-color: $accent; }

/* --- Panel szczegółów --------------------------------------------------- */
#detailPanel { background: $panel; border-left: 1px solid $border; }
#detailTitle { font-size: 17px; font-weight: 700; color: $text; }
#detailLabel { color: $muted; font-size: 12px; }
#detailValue { font-weight: 600; }
#detailSection { font-size: 11px; font-weight: 700; color: $accent2; letter-spacing: 1px; }
#descBox { background: $bg; border: 1px solid $border; border-radius: 9px; padding: 9px; }

/* --- Pokaz slajdów ------------------------------------------------------ */
#slideshow { background: #000000; }
#slideshowBar { background: rgba(0,0,0,180); border-radius: 10px; }
#slideshowButton { background: rgba(255,255,255,25); color: #ffffff; border: 1px solid rgba(255,255,255,60);
                   border-radius: 10px; padding: 9px 15px; font-size: 16px; }
#slideshowButton:hover { background: rgba(255,255,255,55); }

/* --- Różne -------------------------------------------------------------- */
QScrollArea { background: transparent; border: none; }
QScrollBar:vertical { background: transparent; width: 11px; margin: 2px; }
QScrollBar::handle:vertical { background: $border; border-radius: 5px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: $accent; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: transparent; height: 11px; }
QScrollBar::handle:horizontal { background: $border; border-radius: 5px; min-width: 30px; }

QComboBox, QSpinBox, QLineEdit { background: $panel; border: 1px solid $border;
                                 border-radius: 7px; padding: 4px 8px; color: $text; }
QComboBox::drop-down { border: none; }
QComboBox QAbstractItemView { background: $panel; border: 1px solid $border;
                              selection-background-color: $accent; }
QCheckBox::indicator { width: 16px; height: 16px; border-radius: 4px;
                       border: 1px solid $border; background: $panel; }
QCheckBox::indicator:checked { background: $accent; border-color: $accent; }
QTabWidget::pane { border: 1px solid $border; border-radius: 9px; background: $bg2; }
QTabBar::tab { background: $panel; color: $muted; padding: 8px 14px;
               border-top-left-radius: 8px; border-top-right-radius: 8px; }
QTabBar::tab:selected { background: $card; color: $text; border-bottom: 2px solid $accent; }
QToolTip { background: $panel; color: $text; border: 1px solid $accent; padding: 5px; }
QMenu { background: $panel; border: 1px solid $border; }
QMenu::item:selected { background: $accent; color: #ffffff; }
#emptyState { color: $muted; font-size: 15px; }
""")


def stylesheet_for(theme_key: str) -> str:
    theme = THEMES.get(theme_key, THEMES["azureus"])
    return QSS_TEMPLATE.safe_substitute(**theme)


def apply_theme(app: QApplication, theme_key: str) -> None:
    app.setStyleSheet(stylesheet_for(theme_key))


def theme_colors(theme_key: str) -> dict[str, str]:
    return dict(THEMES.get(theme_key, THEMES["azureus"]))
